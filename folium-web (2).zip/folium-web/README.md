# Folium

Editor web de diseño y documentos. Corre en el navegador, sin servidor: el diseño se guarda en el propio navegador y se exporta como PNG, PDF, SVG, Word, HTML, texto o JSON.

## Estructura

```
folium/
├── index.html              Estructura de la página, diálogos y lista de scripts
├── assets/
│   └── folium-mark.svg     Logo vectorizado a partir de la imagen de referencia
├── css/
│   ├── tokens.css          Colores, radios y tema oscuro (solo variables)
│   ├── base.css            Reinicio, tipografía y utilidades
│   ├── layout.css          Barra lateral, barra superior, paneles y modos
│   ├── components.css      Botones, campos, pestañas, diálogos, avisos y listas
│   ├── canvas.css          Lienzo, selección, guías, cuadrícula y capas
│   ├── document.css        Modo documento: cinta de formato y hoja
│   ├── ui-kit.css          Iconos, inicio con tarjetas, paneles con formas y cinta
│   └── responsive.css      Celular: barra compacta y hojas deslizables
├── js/
│   ├── core/
│   │   ├── core.js         Espacio de nombres, eventos, avisos y utilidades
│   │   ├── storage.js      Proyectos en localStorage y migración desde v1
│   │   ├── settings.js     Ajustes: tema, animaciones, cuadrícula, guardado, zoom
│   │   ├── model.js        Tipos de elemento, fuentes, plantillas y geometría
│   │   └── state.js        Proyecto actual, selección e historial (deshacer/rehacer)
│   ├── canvas/
│   │   ├── render.js       Dibujo del lienzo, marco de selección y capas visuales
│   │   ├── actions.js      Agregar, duplicar, copiar, ordenar, alinear, mover
│   │   ├── interact.js     Arrastre, redimensionado, recuadro, guías y atajos
│   │   └── panels.js       Propiedades, texto, capas y alineación
│   ├── ui/
│   │   ├── projects.js     Lista de proyectos, plantillas, renombrar y eliminar
│   │   ├── elements-panel.js  Formas, líneas y presets de texto con miniatura
│   │   └── home.js         Inicio: plantillas y diseños recientes con miniaturas
│   ├── document/
│   │   └── document.js     Modo documento: hoja editable guardada en el proyecto
│   ├── io/
│   │   ├── zip.js          Escritor de ZIP (base de los archivos .docx)
│   │   ├── importers.js    PDF, Word, texto, HTML e imágenes
│   │   └── exporters.js    PNG, PDF vectorial, SVG, Word, HTML, texto y JSON
│   └── app.js              Arranque: conecta interfaz, diálogos y módulos
├── tests/                  Pruebas de extremo a extremo y recorrido con capturas
├── tools/
│   └── vectorize_logo.py   Genera assets/folium-mark.svg desde una imagen
└── README.md
```

El orden de carga está en `index.html`. Cada módulo se añade a `window.Folium`, sin módulos ES, para que funcione también al abrir el archivo localmente.

## Funciones

**Lienzo**
- Formas: rectángulo, círculo, triángulo, estrella, hexágono, pentágono, rombo, corazón, flecha, chevron y cruz.
- Líneas: grosor, trazo sólido, punteado o discontinuo, y flechas al inicio, al final o en ambos extremos.
- Textos con presets de título, subtítulo y cuerpo, e imágenes (máximo 4 MB).
- Selección múltiple: Shift + clic, Ctrl + A o arrastrar un recuadro sobre el fondo.
- Alinear y distribuir (distribuir necesita al menos 3 elementos).
- Orden de capas: al frente, subir, bajar y al fondo. Panel de capas con ocultar y bloquear.
- Propiedades: posición, tamaño, giro, opacidad, esquinas redondeadas y color.
- Texto: negrita, cursiva, alineación, tamaño y tres tipografías.
- Guías inteligentes que alinean bordes y centros con otros elementos y con el lienzo.
- Cuadrícula de 20 px y ajuste opcional a la cuadrícula.
- Deshacer y rehacer hasta 100 pasos.
- Zoom del 25 % al 200 % y ajuste a la pantalla.

**Proyectos**
- Varios diseños guardados en el navegador: crear en blanco o desde plantilla (presentación, póster, publicación), duplicar, renombrar y eliminar.
- Migración automática del diseño de la versión anterior.

**Inicio**
- Plantillas y diseños recientes con miniaturas. Desde aquí se crean diseños y documentos.

**Modo documento**
- Estilo de párrafo, tipografía, tamaño, negrita, cursiva, subrayado, tachado, colores y resaltado.
- Alineación, viñetas, numeración, sangría, enlaces, imágenes, tablas, líneas horizontales y quitar formato.
- La hoja se guarda dentro del proyecto.

**Archivos**
- Importar PDF: abre la primera página como bloques de texto en su posición original.
- Importar Word (.docx), texto (.txt, .md) y HTML: abren en el modo documento. Google Docs se importa descargándolo desde Google Docs como Word, PDF, HTML o texto.
- Importar proyectos (.json) y exportarlos como respaldo.

**Exportar**
- Lienzo: PNG (2×), PDF vectorial, SVG.
- Documento: Word (.docx con títulos, negrita y cursiva), HTML, texto.
- Proyecto: JSON.

**Ajustes**
- Tema: igual que el sistema, claro u oscuro. Animaciones.
- Cuadrícula, ajuste a la cuadrícula y zoom inicial.
- Guardado automático, o manual con Ctrl+S.

## Atajos de teclado

| Atajo | Acción |
|---|---|
| Ctrl + Z / Ctrl + Y | Deshacer / rehacer |
| Ctrl + A | Seleccionar todo |
| Ctrl + C / Ctrl + V | Copiar y pegar |
| Ctrl + D | Duplicar |
| Ctrl + ] / Ctrl + [ | Traer al frente / enviar atrás |
| Supr | Eliminar |
| Flechas (Shift: 10 px) | Mover |
| Esc | Quitar la selección |
| Ctrl + S | Guardar |
| ? | Mostrar los atajos |

## Cómo probarlo

Abre `index.html` en el navegador. En celular, **+ Agregar** abre las formas y **Diseño** abre las propiedades.

Las funciones que cargan librerías (importar PDF y Word) necesitan conexión a cdnjs.cloudflare.com.

## Pruebas

```bash
pip install playwright && playwright install chromium
python tests/test_folium.py      # 87 pruebas de funciones
python tests/capturas.py         # recorrido de demostración con capturas
```

Consulta `tests/README.md` para el detalle de cada grupo.

## Publicar en Netlify

Arrastra la carpeta del sitio (sin `tests` ni `tools`) al panel de Netlify Drop. Se publica con una dirección `.netlify.app`.

## Limitaciones conocidas

- El PDF usa las fuentes estándar Helvetica, Times y Courier. Inter y otras fuentes web no se incrustan.
- El PDF importado conserva solo la primera página y el texto; no importa imágenes ni dibujos.
- El Word exportado no incluye imágenes ni tablas. El importado tampoco.
- Los proyectos viven en el navegador. Si se borran los datos del sitio, se pierden.
- No hay cuentas ni colaboración: harían falta un servidor y un inicio de sesión.

## Efectos, biblioteca y fuentes (versión 3)

**Efectos de cualquier elemento** (panel Efectos del lienzo):
- Degradado con 8 presets, colores propios y ángulo.
- Sombra con color, desenfoque y desplazamiento.
- Contorno de forma o de texto con color y grosor.
- Resaltado de fondo en textos.
- Volteo horizontal y vertical.

**Imágenes del lienzo:** máscara de forma (círculo, esquinas redondeadas o cualquier forma de la biblioteca), brillo, contraste, saturación, desenfoque, escala de grises y sepia.

**Biblioteca** (pestaña Elementos): 13 iconos, 6 stickers, 4 marcos y 8 fondos degradados. Los fondos se agregan como un rectángulo del tamaño del lienzo, al fondo de todo. Los assets son trazos SVG que se colorean con el color del elemento.

**Tipografías:** 12 familias, incluidas Montserrat, Poppins, Oswald, Bebas Neue, Playfair Display, Lora, Merriweather, Pacifico y Dancing Script (se cargan desde Google Fonts, así que necesitan conexión).

**Documento:**
- Las imágenes se pueden seleccionar y editar: forma (cuadrada, circular, redondeada o de la biblioteca), proporción (original, 1:1, 4:3, 16:9), ancho (25 a 100 %), alineación, brillo, grises, sepia, volteo, giro de 90° y quitar.
- Texto con degradado (9 opciones), resaltado de color, tipografía y tamaño.

**Limitaciones de exportación:**
- En el PDF, los elementos con efectos (degradado, sombra, contorno, máscara, filtros o assets) se incrustan como imagen con transparencia. Su texto no se puede seleccionar. El resto sigue siendo vectorial.
- El PDF usa Helvetica, Times o Courier como fuentes incrustables; las familias de Google se sustituyen por la estándar más parecida.
- El SVG incluye degradados, sombras, contornos, máscaras, volteo, assets y resaltados, pero no los filtros de brillo y contraste de las imágenes.
- El Word exportado no incluye imágenes.

## Versión 4: lo aprendido de un video de editor con IA

Se analizó un video en el que un creador construye su propio editor de imágenes con ayuda de asistentes de IA. Se tomaron estas ideas:

- **Tamaños predefinidos** al crear diseños: miniatura de YouTube, Instagram (publicación e historia), Full HD y A4. Se crean desde la pantalla de proyectos.
- **Fondo transparente**, con cuadros de transparencia en el lienzo. Se exporta con transparencia en PNG.
- **Exportación a medida:** formato (PNG o JPG), escala (1×, 2×, 3×) y calidad de JPG.
- **Tirador de giro** en el lienzo: arrastrarlo gira el elemento (Mayús: pasos de 15°).
- **Resplandor** (sombra sin desplazamiento) en el panel de efectos.
- **Renombrar capas:** segundo clic en el nombre de la capa.
- **Pegar imágenes** desde el portapapeles (Ctrl+V) y **arrastrar imágenes** al lienzo.

Lo que no se implementó todavía: pincel, borrador, pluma de curvas, selección por contorno y la importación de archivos de Photoshop (PSD).
