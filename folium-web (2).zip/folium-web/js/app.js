/* Folium · arranque: vistas (Inicio, lienzo, documento), navegación, diálogos e importaciones */
(function () {
  'use strict';
  const F = window.Folium, S = F.state, $ = F.$, $$ = F.$$;
  const IO = F.io;
  const app = document.getElementById('app');
  const modeBtn = $('#modeBtn');
  const NAV_FOR_VIEW = { home: 'inicio', canvas: 'diseno', doc: 'documento' };

  // ---------- Vistas ----------
  F.setView = (view) => {
    if (view !== 'doc') F.document.flush();
    app.classList.toggle('is-home', view === 'home');
    app.classList.toggle('is-doc', view === 'doc');
    modeBtn.setAttribute('aria-pressed', String(view === 'doc'));
    modeBtn.setAttribute('aria-label', view === 'doc' ? 'Volver al modo lienzo' : 'Cambiar a modo documento');
    $$('.nav button[data-nav], .nav-foot button[data-nav]').forEach((b) => {
      if (b.dataset.nav === NAV_FOR_VIEW[view]) b.setAttribute('aria-current', 'page');
      else b.removeAttribute('aria-current');
    });
    openSheet(null);
    if (view === 'home') F.home.render();
    if (view === 'doc') { F.document.load(); $('#page').focus(); }
    modeBtn.classList.remove('pop');
    void modeBtn.offsetWidth;
    modeBtn.classList.add('pop');
    F.emit('mode', { view });
  };

  modeBtn.addEventListener('click', () => {
    F.setView(app.classList.contains('is-doc') ? 'canvas' : 'doc');
  });

  // ---------- Hojas deslizables (celular) ----------
  function openSheet(name) {
    app.classList.toggle('show-left', name === 'left');
    app.classList.toggle('show-right', name === 'right');
    $('#toggleLeft').setAttribute('aria-expanded', String(name === 'left'));
    $('#toggleRight').setAttribute('aria-expanded', String(name === 'right'));
  }
  $('#toggleLeft').addEventListener('click', () => openSheet(app.classList.contains('show-left') ? null : 'left'));
  $('#toggleRight').addEventListener('click', () => openSheet(app.classList.contains('show-right') ? null : 'right'));
  $$('[data-close]').forEach((b) => b.addEventListener('click', () => openSheet(null)));
  $('#artboard').addEventListener('pointerdown', () => { if (F.isMobile()) openSheet(null); });

  // ---------- Pestañas del panel izquierdo ----------
  const bodies = { tabElements: $('#tabElements'), tabLayers: $('#tabLayers'), tabUploads: $('#tabUploads') };
  $$('.tabs button[data-tab]').forEach((tab) => {
    tab.addEventListener('click', () => {
      $$('.tabs button[data-tab]').forEach((t) => t.setAttribute('aria-selected', String(t === tab)));
      Object.keys(bodies).forEach((k) => { bodies[k].hidden = k !== tab.dataset.tab; });
    });
  });

  // ---------- Barra superior ----------
  $('#undoBtn').addEventListener('click', () => S.undoStep());
  $('#redoBtn').addEventListener('click', () => S.redoStep());
  $('#zoomOut').addEventListener('click', () => F.setZoom(F.zoomIndex() - 1));
  $('#zoomIn').addEventListener('click', () => F.setZoom(F.zoomIndex() + 1));
  $('#zoomFit').addEventListener('click', () => F.zoomToFit());

  function openDialog(id) {
    const d = document.getElementById(id);
    if (d && typeof d.showModal === 'function') d.showModal();
  }
  ['exportOpen', 'exportOpenDoc', 'exportOpenMobile'].forEach((id) => {
    const b = document.getElementById(id);
    if (b) b.addEventListener('click', () => openDialog('exportDialog'));
  });

  // ---------- Navegación ----------
  $$('[data-nav]').forEach((b) => {
    b.addEventListener('click', () => {
      const n = b.dataset.nav;
      if (n === 'inicio') F.setView('home');
      if (n === 'diseno') F.setView('canvas');
      if (n === 'documento') F.setView('doc');
      if (n === 'proyectos') { F.projects.render(); openDialog('projectsDialog'); }
      if (n === 'plantillas') { F.projects.render(); openDialog('projectsDialog'); $('#tplSelect').focus(); }
      if (n === 'exportar') openDialog('exportDialog');
      if (n === 'atajos') openDialog('shortcutsDialog');
    });
  });

  // ---------- Diálogos ----------
  $$('dialog.modal').forEach((d) => {
    d.addEventListener('click', (e) => { if (e.target === d) d.close(); });
  });
  $$('[data-dialog-close]').forEach((b) => b.addEventListener('click', () => b.closest('dialog').close()));

  $$('[data-export]').forEach((b) => {
    b.addEventListener('click', () => {
      b.closest('dialog').close();
      F.exp.run(b.dataset.export);
    });
  });

  $('#exCustom').addEventListener('click', async () => {
    const fmt = $('#exFormat').value, scale = Number($('#exScale').value), q = Number($('#exQuality').value) / 100;
    $('#exportDialog').close();
    await F.exp.custom(fmt, scale, q);
  });

  // ---------- Ajustes: datos ----------
  $('#saveNowBtn').addEventListener('click', () => { if (S.save()) F.toast('Proyecto guardado', 'ok', 1400); });
  $('#exportJsonBtn').addEventListener('click', () => F.exp.run('json'));
  $('#resetBtn').addEventListener('click', () => {
    if (!window.confirm('¿Restablecer el lienzo de este proyecto a la plantilla de presentación? Puedes deshacerlo con Ctrl+Z.')) return;
    const c = S.canvas();
    c.width = 1280; c.height = 720; c.background = '#FFFFFF';
    c.elements = F.TEMPLATES.presentacion.make();
    S.setSelection([]);
    S.commit();
    F.toast('Lienzo restablecido', 'ok');
  });

  $('#importJsonInput').addEventListener('change', async (ev) => {
    const file = ev.target.files[0];
    ev.target.value = '';
    if (!file) return;
    try {
      const data = JSON.parse(await F.readAs(file, 'text'));
      let project;
      if (data && data.format === 'folium' && data.project) {
        project = JSON.parse(JSON.stringify(data.project));
      } else if (data && data.doc && Array.isArray(data.elements)) {
        project = F.newProject(data.doc.title || 'Importado');
        project.canvas = { width: data.doc.width, height: data.doc.height, background: data.doc.background || '#FFFFFF', elements: data.elements };
      } else {
        throw new Error('El archivo no es un proyecto de Folium');
      }
      project.id = F.uid('p');
      project.updated = Date.now();
      S.data.projects[project.id] = project;
      S.openProject(project.id);
      F.emit('project');
      F.setView('canvas');
      F.toast('Proyecto importado', 'ok');
    } catch (err) {
      F.toast(err.message || 'No se pudo importar el proyecto', 'error', 5000);
    }
  });

  // ---------- Archivos: imágenes ----------
  $('#fileInput').addEventListener('change', async (ev) => {
    const file = ev.target.files[0];
    ev.target.value = '';
    if (!file) return;
    try {
      const img = await IO.importImage(file);
      F.actions.add('image', { src: img.src, w: img.w, h: img.h, name: file.name.slice(0, 24) });
      openSheet(null);
      F.toast('Imagen agregada', 'ok', 1600);
    } catch (err) {
      F.toast(err.message || 'No se pudo subir la imagen', 'error', 4500);
    }
  });

  // ---------- Archivos: PDF, Word, texto y HTML ----------
  async function importPdfToCanvas(file) {
    const result = await IO.importPdf(file);
    const c = S.canvas();
    c.width = result.width;
    c.height = result.height;
    c.background = '#FFFFFF';
    c.elements = result.elements;
    S.project().name = result.title || S.project().name;
    S.setSelection([]);
    S.commit();
    F.projects.syncTitles();
    F.setView('canvas');
    F.toast(`PDF importado: ${result.elements.length} bloques de texto (página 1 de ${result.pages})`, 'ok', 4000);
  }

  async function importDocToDocument(file, run, label) {
    const result = await run(file);
    if (!window.confirm('Esto reemplaza el contenido del modo documento. ¿Continuar?')) {
      F.toast('Importación cancelada', '', 1800);
      return;
    }
    F.document.setHtml(result.html);
    S.project().name = result.title || S.project().name;
    S.commit();
    F.projects.syncTitles();
    F.setView('doc');
    F.toast(`${label} importado`, 'ok');
  }

  $('#importInput').addEventListener('change', async (ev) => {
    const file = ev.target.files[0];
    ev.target.value = '';
    if (!file) return;
    const name = file.name.toLowerCase();
    try {
      F.setStatus('Importando…');
      if (name.endsWith('.pdf')) await importPdfToCanvas(file);
      else if (name.endsWith('.docx')) await importDocToDocument(file, IO.importDocx, 'Word');
      else if (/\.(txt|md)$/.test(name)) await importDocToDocument(file, IO.importText, 'Texto');
      else if (/\.html?$/.test(name)) await importDocToDocument(file, IO.importHtml, 'HTML');
      else F.toast('Formato no compatible: usa PDF, Word, texto o HTML', 'error', 4500);
    } catch (err) {
      console.error(err);
      F.toast(err.message || 'No se pudo importar el archivo', 'error', 6000);
    } finally {
      F.setStatus('Guardado');
    }
  });

  // Los botones de la cinta no deben quitar la selección de la hoja
  $$('[data-cmd], [data-act]').forEach((b) => b.addEventListener('mousedown', (e) => e.preventDefault()));

  // ---------- Imágenes arrastradas al lienzo o pegadas desde el portapapeles ----------
  async function addImageFile(file) {
    try {
      const img = await IO.importImage(file);
      F.actions.add('image', { src: img.src, w: img.w, h: img.h, name: file.name.slice(0, 24) });
      F.toast('Imagen agregada', 'ok', 1600);
    } catch (err) {
      F.toast(err.message || 'No se pudo agregar la imagen', 'error', 4500);
    }
  }
  const stage = $('#stageScroll');
  stage.addEventListener('dragover', (e) => { e.preventDefault(); });
  stage.addEventListener('drop', (e) => {
    e.preventDefault();
    [...(e.dataTransfer ? e.dataTransfer.files : [])].filter((f) => f.type.startsWith('image/')).forEach(addImageFile);
  });
  document.addEventListener('paste', (e) => {
    if (app.classList.contains('is-doc') || e.target.closest('input, textarea, select, [contenteditable="true"]')) return;
    const item = [...(e.clipboardData ? e.clipboardData.items : [])].find((i) => i.type.startsWith('image/'));
    const file = item && item.getAsFile();
    if (file) addImageFile(file);
  });

  // ---------- Salida con cambios pendientes ----------
  window.addEventListener('beforeunload', (e) => {
    if (S.dirty) { e.preventDefault(); e.returnValue = ''; }
  });

  // ---------- Arranque ----------
  S.init();
  F.setZoom(F.isMobile() ? 0 : F.zoomIndexFor(F.settings.get('defaultZoom')));
  F.projects.init();
  F.document.init();
  F.home.init();
  F.elementsPanel.build();
  F.render.canvas();
  F.panels.update();
  F.emit('project');
  F.setView('home');
  F.emit('ready');
})();
