/* Folium · estado: proyecto actual, selección, historial (deshacer/rehacer) y persistencia */
(function () {
  'use strict';
  const F = window.Folium;
  const MAX_HISTORY = 100;
  const S = { data: null, selection: [], undo: [], redo: [], committed: '', dirty: false, clipboard: null };
  F.state = S;

  S.project = () => S.data.projects[S.data.currentId];
  S.canvas = () => S.project().canvas;
  S.els = () => S.canvas().elements;
  S.find = (id) => S.els().find((e) => e.id === id);
  S.selected = () => S.els().filter((e) => S.selection.includes(e.id));
  S.projects = () => Object.values(S.data.projects).sort((a, b) => b.updated - a.updated);

  S.init = () => {
    S.data = F.storage.load();
    S.openProject(S.data.currentId, true);
  };

  S.setSelection = (ids) => {
    S.selection = ids.filter((id) => S.find(id));
    F.emit('selection');
  };

  S.snapshot = () => JSON.stringify(S.canvas());

  S.save = () => {
    if (F.storage.save(S.data)) { S.dirty = false; F.setStatus('Guardado'); return true; }
    return false;
  };

  // Guarda ahora o marca como pendiente, según el ajuste de guardado automático
  S.persist = () => {
    S.project().updated = Date.now();
    if (F.settings.get('autosave')) S.save();
    else { S.dirty = true; F.setStatus('Cambios sin guardar · Ctrl+S'); }
  };

  // Cambio terminado: se guarda en el historial y se persiste
  S.commit = () => {
    const now = S.snapshot();
    if (now === S.committed) return;
    S.undo.push(S.committed);
    if (S.undo.length > MAX_HISTORY) S.undo.shift();
    S.committed = now;
    S.redo = [];
    S.persist();
    F.emit('change');
  };

  // Cambio en curso (arrastre, escritura): se muestra sin tocar el historial
  S.live = () => F.emit('live');

  S.restore = (json) => {
    S.project().canvas = JSON.parse(json);
    S.committed = json;
    S.selection = S.selection.filter((id) => S.find(id));
    S.persist();
    F.emit('change');
  };

  S.undoStep = () => {
    if (!S.undo.length) return false;
    S.redo.push(S.committed);
    S.restore(S.undo.pop());
    F.toast('Deshacer', '', 1200);
    return true;
  };

  S.redoStep = () => {
    if (!S.redo.length) return false;
    S.undo.push(S.committed);
    S.restore(S.redo.pop());
    F.toast('Rehacer', '', 1200);
    return true;
  };

  S.openProject = (id, silent) => {
    if (!S.data.projects[id]) return;
    if (S.dirty) S.save();
    S.data.currentId = id;
    S.selection = [];
    S.undo = [];
    S.redo = [];
    S.committed = S.snapshot();
    S.dirty = false;
    F.setStatus('Guardado');
    if (!silent) { S.save(); F.emit('project'); }
  };

  S.addProject = (name, templateId) => {
    const p = F.newProject(name, templateId);
    S.data.projects[p.id] = p;
    S.openProject(p.id);
    return p;
  };

  S.duplicateProject = (id) => {
    const src = S.data.projects[id];
    if (!src) return null;
    const copy = JSON.parse(JSON.stringify(src));
    copy.id = F.uid('p');
    copy.name = src.name + ' (copia)';
    copy.updated = Date.now();
    copy.canvas.elements.forEach((e) => { e.id = F.uid('e'); });
    S.data.projects[copy.id] = copy;
    S.save();
    return copy;
  };

  S.deleteProject = (id) => {
    if (Object.keys(S.data.projects).length <= 1) return false;
    delete S.data.projects[id];
    if (S.data.currentId === id) S.openProject(S.projects()[0].id);
    else S.save();
    F.emit('project');
    return true;
  };
})();
