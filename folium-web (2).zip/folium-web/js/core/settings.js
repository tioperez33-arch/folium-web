/* Folium · ajustes del usuario: tema, animaciones, cuadrícula, ajuste, guardado y zoom inicial */
(function () {
  'use strict';
  const F = window.Folium;
  const KEY = 'folium-settings-v1';
  const DEFAULTS = { theme: 'system', motion: true, showGrid: false, snap: false, autosave: true, defaultZoom: 50 };
  const state = { ...DEFAULTS };
  const media = window.matchMedia('(prefers-color-scheme: dark)');

  function load() {
    try {
      const raw = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (raw && typeof raw === 'object') {
        Object.keys(DEFAULTS).forEach((k) => {
          if (typeof raw[k] === typeof DEFAULTS[k]) state[k] = raw[k];
        });
      }
    } catch (err) { /* ajustes dañados: se usan los predeterminados */ }
  }

  function persist() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (err) { /* sin espacio: sigue activo en la sesión */ }
  }

  function applyToDocument() {
    const dark = state.theme === 'dark' || (state.theme === 'system' && media.matches);
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    document.documentElement.classList.toggle('no-motion', !state.motion);
  }

  function set(key, value) {
    if (!(key in DEFAULTS) || typeof value !== typeof DEFAULTS[key] || state[key] === value) return;
    state[key] = value;
    persist();
    applyToDocument();
    F.emit('settings', { ...state });
  }

  function syncControls() {
    const map = { setTheme: 'theme', setMotion: 'motion', setGrid: 'showGrid', setSnap: 'snap', setAutosave: 'autosave', setZoomDefault: 'defaultZoom' };
    Object.keys(map).forEach((id) => {
      const el = document.getElementById(id);
      if (!el) return;
      const v = state[map[id]];
      if (el.type === 'checkbox') el.checked = v; else el.value = String(v);
    });
  }

  function bind() {
    const dialog = document.getElementById('settingsDialog');
    const open = document.getElementById('openSettings');
    if (open && dialog) {
      open.addEventListener('click', () => { syncControls(); dialog.showModal(); });
    }
    const readers = [
      ['setTheme', 'theme', (el) => el.value],
      ['setMotion', 'motion', (el) => el.checked],
      ['setGrid', 'showGrid', (el) => el.checked],
      ['setSnap', 'snap', (el) => el.checked],
      ['setAutosave', 'autosave', (el) => el.checked],
      ['setZoomDefault', 'defaultZoom', (el) => Number(el.value)]
    ];
    readers.forEach(([id, key, read]) => {
      const el = document.getElementById(id);
      if (el) el.addEventListener('change', () => set(key, read(el)));
    });
    if (media.addEventListener) media.addEventListener('change', applyToDocument);
  }

  load();
  applyToDocument();
  F.settings = { get: (k) => state[k], set, all: () => ({ ...state }), bind };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind); else bind();
})();
