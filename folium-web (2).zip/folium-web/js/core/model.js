/* Folium · modelo: tipos de elemento, formas, líneas, fuentes, plantillas y geometría */
(function () {
  'use strict';
  const F = window.Folium;

  // Familias disponibles. "css" se usa en pantalla y "pdf" es la familia estándar más parecida en PDF.
  F.FONTS = {
    inter: { label: 'Inter', css: "Inter, system-ui, sans-serif", pdf: 'Helvetica' },
    montserrat: { label: 'Montserrat', css: "'Montserrat', sans-serif", pdf: 'Helvetica' },
    poppins: { label: 'Poppins', css: "'Poppins', sans-serif", pdf: 'Helvetica' },
    oswald: { label: 'Oswald', css: "'Oswald', sans-serif", pdf: 'Helvetica' },
    bebas: { label: 'Bebas Neue', css: "'Bebas Neue', sans-serif", pdf: 'Helvetica' },
    playfair: { label: 'Playfair Display', css: "'Playfair Display', serif", pdf: 'Times' },
    lora: { label: 'Lora', css: "'Lora', serif", pdf: 'Times' },
    merriweather: { label: 'Merriweather', css: "'Merriweather', serif", pdf: 'Times' },
    serif: { label: 'Georgia', css: "Georgia, 'Times New Roman', serif", pdf: 'Times' },
    pacifico: { label: 'Pacifico', css: "'Pacifico', cursive", pdf: 'Times' },
    dancing: { label: 'Dancing Script', css: "'Dancing Script', cursive", pdf: 'Times' },
    mono: { label: 'Monoespaciada', css: "ui-monospace, Menlo, Consolas, monospace", pdf: 'Courier' }
  };
  F.fontOf = (id) => F.FONTS[id] || F.FONTS.inter;

  // Formas poligonales. Cada una se define en un cuadro 0-100 y se estira al tamaño del elemento.
  F.SHAPES = {
    star: 'Estrella', hexagon: 'Hexágono', pentagon: 'Pentágono', diamond: 'Rombo',
    heart: 'Corazón', arrow: 'Flecha', chevron: 'Chevron', cross: 'Cruz'
  };

  const normalize = (pts) => {
    const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]);
    const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
    return pts.map(([x, y]) => [((x - x0) / (x1 - x0)) * 100, ((y - y0) / (y1 - y0)) * 100]);
  };
  const regular = (n, start) => Array.from({ length: n }, (_, i) => {
    const a = start + (i * 2 * Math.PI) / n;
    return [50 + 50 * Math.cos(a), 50 + 50 * Math.sin(a)];
  });
  const POLY = {
    star: () => Array.from({ length: 10 }, (_, i) => {
      const r = i % 2 ? 22 : 50, a = -Math.PI / 2 + (i * Math.PI) / 5;
      return [50 + r * Math.cos(a), 50 + r * Math.sin(a)];
    }),
    hexagon: () => regular(6, -Math.PI / 2),
    pentagon: () => regular(5, -Math.PI / 2),
    diamond: () => [[50, 0], [100, 50], [50, 100], [0, 50]],
    heart: () => {
      const pts = [];
      for (let i = 0; i <= 72; i++) {
        const t = (i / 72) * 2 * Math.PI;
        const x = 16 * Math.pow(Math.sin(t), 3);
        const y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
        pts.push([x, -y]);
      }
      return pts;
    },
    arrow: () => [[0, 35], [55, 35], [55, 10], [100, 50], [55, 90], [55, 65], [0, 65]],
    chevron: () => [[0, 0], [60, 0], [100, 50], [60, 100], [0, 100], [40, 50]],
    cross: () => [[35, 0], [65, 0], [65, 35], [100, 35], [100, 65], [65, 65], [65, 100], [35, 100], [35, 65], [0, 65], [0, 35], [35, 35]]
  };
  F.shapePoints = (name) => normalize((POLY[name] || POLY.diamond)());

  // Propiedades predeterminadas de cada tipo de elemento
  F.DEFAULTS = {
    rect: { w: 320, h: 200, fill: '#2563FF', radius: 16, name: 'Rectángulo' },
    ellipse: { w: 240, h: 240, fill: '#7A3CFF', name: 'Círculo' },
    triangle: { w: 260, h: 220, fill: '#0A84FF', name: 'Triángulo' },
    poly: { w: 220, h: 200, fill: '#FFB020', shape: 'star', name: 'Estrella' },
    line: { w: 360, h: 4, fill: '#0E1330', dash: 'solid', arrow: 'none', name: 'Línea' },
    text: { w: 520, h: 110, fill: '#0E1330', text: 'Escribe aquí', size: 56, weight: 700, italic: false, align: 'left', font: 'inter', name: 'Texto' },
    image: { w: 320, h: 240, name: 'Imagen' },
    asset: { w: 200, h: 200, fill: '#2563FF', aid: 'heart', name: 'Elemento' }
  };

  // Propiedades comunes a todos los elementos
  F.makeElement = (type, props) => ({
    id: F.uid('e'), type, x: 0, y: 0, rot: 0, op: 1, hidden: false, locked: false,
    ...F.DEFAULTS[type], ...(props || {})
  });

  const T = (type, props) => F.makeElement(type, props);
  F.TEMPLATES = {
    presentacion: {
      label: 'Presentación', width: 1280, height: 720, background: '#FFFFFF',
      make: () => [
        T('ellipse', { x: 880, y: -140, w: 520, h: 520, fill: '#DCE6FF' }),
        T('ellipse', { x: -180, y: 470, w: 420, h: 420, fill: '#E7DEFF' }),
        T('text', { x: 120, y: 230, w: 760, h: 44, text: 'Título de la presentación', size: 28, weight: 500, fill: '#6B7594' }),
        T('text', { x: 120, y: 280, w: 900, h: 130, text: 'Tu idea, clara y lista para compartir', size: 80, weight: 700 })
      ]
    },
    poster: {
      label: 'Póster', width: 1080, height: 1350, background: '#F3F6FD',
      make: () => [
        T('rect', { x: 0, y: 0, w: 1080, h: 520, radius: 0, fill: '#2563FF' }),
        T('text', { x: 80, y: 150, w: 920, h: 200, text: 'Título del evento', size: 88, weight: 700, fill: '#FFFFFF' }),
        T('text', { x: 80, y: 600, w: 920, h: 300, text: 'Fecha · lugar · detalles', size: 44, weight: 500 }),
        T('poly', { x: 720, y: 900, w: 300, h: 300, shape: 'star', fill: '#7A3CFF', name: 'Estrella' })
      ]
    },
    social: {
      label: 'Publicación', width: 1080, height: 1080, background: '#0E1330',
      make: () => [
        T('ellipse', { x: 640, y: -120, w: 600, h: 600, fill: '#2563FF' }),
        T('text', { x: 90, y: 360, w: 900, h: 260, text: 'Una frase que se recuerda', size: 84, weight: 700, fill: '#FFFFFF' }),
        T('line', { x: 90, y: 700, w: 240, h: 6, fill: '#FFB020', arrow: 'none' }),
        T('text', { x: 90, y: 880, w: 900, h: 60, text: '@tu_marca', size: 34, weight: 500, fill: '#98A3C7' })
      ]
    }
  };

  // Tamaños predefinidos (en píxeles) para crear diseños a medida
  F.SIZE_PRESETS = [
    { id: 'yt-thumb', label: 'Miniatura de YouTube (1280 × 720)', w: 1280, h: 720 },
    { id: 'ig-post', label: 'Instagram: publicación (1080 × 1080)', w: 1080, h: 1080 },
    { id: 'ig-story', label: 'Instagram: historia (1080 × 1920)', w: 1080, h: 1920 },
    { id: 'full-hd', label: 'Full HD (1920 × 1080)', w: 1920, h: 1080 },
    { id: 'a4', label: 'A4 vertical (794 × 1123)', w: 794, h: 1123 }
  ];

  F.newProject = (name, templateId) => {
    const tpl = F.TEMPLATES[templateId];
    const title = name || (tpl ? tpl.label : 'Diseño sin título');
    return {
      id: F.uid('p'),
      name: title,
      updated: Date.now(),
      canvas: tpl
        ? { width: tpl.width, height: tpl.height, background: tpl.background, elements: tpl.make() }
        : { width: 1280, height: 720, background: '#FFFFFF', elements: [] },
      doc: { html: `<h1>${F.esc(title)}</h1><p>Escribe aquí tu documento.</p>` }
    };
  };

  // Caja sin rotar del elemento
  F.box = (el) => ({ x: el.x, y: el.y, w: el.w, h: el.h });

  // Caja que contiene al elemento girado (para dibujar el marco de selección)
  F.rotatedBox = (el) => {
    const cx = el.x + el.w / 2, cy = el.y + el.h / 2;
    const a = ((el.rot || 0) * Math.PI) / 180;
    const cos = Math.cos(a), sin = Math.sin(a);
    const pts = [[el.x, el.y], [el.x + el.w, el.y], [el.x + el.w, el.y + el.h], [el.x, el.y + el.h]].map(([px, py]) => {
      const dx = px - cx, dy = py - cy;
      return [cx + dx * cos - dy * sin, cy + dx * sin + dy * cos];
    });
    const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]);
    return { x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) };
  };

  // Caja que contiene a un conjunto de elementos (sin rotar)
  F.unionBox = (els) => {
    const x0 = Math.min(...els.map((e) => e.x)), y0 = Math.min(...els.map((e) => e.y));
    const x1 = Math.max(...els.map((e) => e.x + e.w)), y1 = Math.max(...els.map((e) => e.y + e.h));
    return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
  };
})();
