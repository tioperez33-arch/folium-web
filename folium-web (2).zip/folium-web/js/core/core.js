/* Folium · núcleo: espacio de nombres, eventos, utilidades y avisos */
(function () {
  'use strict';
  const F = (window.Folium = window.Folium || {});

  F.$ = (sel, root) => (root || document).querySelector(sel);
  F.$$ = (sel, root) => [...(root || document).querySelectorAll(sel)];
  F.uid = (prefix) => (prefix || 'e') + Math.random().toString(36).slice(2, 9);
  F.clamp = (v, min, max) => Math.min(max, Math.max(min, v));
  F.round = (v) => Math.round(v * 100) / 100;
  F.isMobile = () => window.matchMedia('(max-width: 900px)').matches;
  F.esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));

  // Eventos internos: "selection", "change", "live", "project", "history", "mode"
  const handlers = {};
  F.on = (name, fn) => { (handlers[name] = handlers[name] || []).push(fn); };
  F.emit = (name, data) => (handlers[name] || []).forEach((fn) => fn(data));

  // Aviso breve en pantalla
  F.toast = (msg, kind, ms) => {
    const box = F.$('#toasts');
    if (!box) return;
    const el = document.createElement('div');
    el.className = 'toast ' + (kind || '');
    el.setAttribute('role', 'status');
    el.textContent = msg;
    box.appendChild(el);
    setTimeout(() => el.remove(), ms || 3200);
  };

  // Estado visible junto al título
  F.setStatus = (text) => {
    const el = F.$('#saveState');
    if (el) el.textContent = text;
  };

  // Descarga de un Blob o texto
  F.download = (data, filename, mime) => {
    const blob = data instanceof Blob ? data : new Blob([data], { type: mime || 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  };

  F.safeName = (name) => (String(name || 'diseño').replace(/[\\/:*?"<>|]+/g, '').trim() || 'diseño');

  F.readAs = (file, how) => new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(new Error('No se pudo leer el archivo'));
    if (how === 'text') r.readAsText(file); else if (how === 'buffer') r.readAsArrayBuffer(file); else r.readAsDataURL(file);
  });

  F.loadImage = (src) => new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('No se pudo abrir la imagen'));
    img.src = src;
  });
})();
