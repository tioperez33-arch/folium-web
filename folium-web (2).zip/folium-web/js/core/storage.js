/* Folium · almacenamiento: proyectos en localStorage con migración desde la versión anterior */
(function () {
  'use strict';
  const F = window.Folium;
  const KEY = 'folium-projects-v2';
  const OLD_KEY = 'folium-canvas-v1';

  function readRaw(key) {
    try { return JSON.parse(localStorage.getItem(key) || 'null'); } catch (err) { return null; }
  }

  F.storage = {
    load() {
      const data = readRaw(KEY);
      if (data && data.projects && Object.keys(data.projects).length) {
        if (!data.projects[data.currentId]) data.currentId = Object.keys(data.projects)[0];
        return data;
      }

      // Migración: si existe el diseño de la versión anterior, se conserva como primer proyecto
      const out = { currentId: null, projects: {} };
      const old = readRaw(OLD_KEY);
      if (old && old.doc) {
        const p = F.newProject(old.doc.title || 'Diseño sin título');
        p.canvas = {
          width: old.doc.width, height: old.doc.height,
          background: old.doc.background || '#FFFFFF', elements: old.elements || []
        };
        out.projects[p.id] = p;
        out.currentId = p.id;
      }
      if (!out.currentId) {
        const p = F.newProject('Diseño sin título', 'presentacion');
        out.projects[p.id] = p;
        out.currentId = p.id;
      }
      return out;
    },

    save(data) {
      try {
        localStorage.setItem(KEY, JSON.stringify(data));
        return true;
      } catch (err) {
        F.toast('No hay espacio en el navegador. Quita imágenes grandes o exporta el proyecto.', 'error', 6000);
        return false;
      }
    }
  };
})();
