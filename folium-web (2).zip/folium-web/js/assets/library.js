/* Folium · biblioteca de assets: iconos, stickers, marcos y degradados de fondo.
   Cada asset es una lista de trazos SVG en un viewBox propio; se colorea con el relleno del elemento. */
(function () {
  'use strict';
  const F = window.Folium;

  // Degradados predefinidos (inicio y fin) para fondos, formas y textos
  F.GRADIENTS = {
    sunset: { label: 'Atardecer', c1: '#FF7A18', c2: '#AF002D' },
    ocean: { label: 'Océano', c1: '#2193B0', c2: '#6DD5ED' },
    forest: { label: 'Bosque', c1: '#11998E', c2: '#38EF7D' },
    candy: { label: 'Caramelo', c1: '#FF9A9E', c2: '#FBC2EB' },
    gold: { label: 'Oro', c1: '#F7971E', c2: '#FFD200' },
    night: { label: 'Noche', c1: '#0F2027', c2: '#2C5364' },
    royal: { label: 'Real', c1: '#4776E6', c2: '#8E54E9' },
    peach: { label: 'Durazno', c1: '#FFECD2', c2: '#FCB69F' }
  };

  // Estrella o polígono regular centrado en (50, 50) dentro de un cuadro de 100
  const starPts = (n, ro, ri) => Array.from({ length: n * 2 }, (_, i) => {
    const r = i % 2 ? ri : ro, a = -Math.PI / 2 + (i * Math.PI) / n;
    return [50 + r * Math.cos(a), 50 + r * Math.sin(a)];
  });
  const polyD = (pts) => 'M' + pts.map((p) => p[0].toFixed(2) + ' ' + p[1].toFixed(2)).join('L') + 'Z';

  F.ASSETS = [
    // ----- Iconos (24 × 24) -----
    { id: 'heart', cat: 'icon', label: 'Corazón', vb: '0 0 24 24', paths: ['M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z'] },
    { id: 'star-i', cat: 'icon', label: 'Estrella', vb: '0 0 24 24', paths: ['M12 2.5l2.9 6.2 6.8.7-5.1 4.6 1.5 6.7L12 17.4 5.9 20.7l1.5-6.7L2.3 9.4l6.8-.7L12 2.5z'] },
    { id: 'check', cat: 'icon', label: 'Check', vb: '0 0 24 24', rule: 'evenodd', paths: ['M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM10.5 16.5l-4-4 1.4-1.4 2.6 2.6 5.6-5.6 1.4 1.4-7 7z'] },
    { id: 'arrow', cat: 'icon', label: 'Flecha', vb: '0 0 24 24', paths: ['M4 11h11.2l-4.6-4.6L12 5l7 7-7 7-1.4-1.4 4.6-4.6H4z'] },
    { id: 'cloud', cat: 'icon', label: 'Nube', vb: '0 0 24 24', paths: ['M7 18a4.5 4.5 0 0 1-.6-8.96A6 6 0 0 1 18 9.5a4 4 0 0 1 .5 7.96V18H7z'] },
    { id: 'sun', cat: 'icon', label: 'Sol', vb: '0 0 24 24', paths: ['M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10z', 'M11 1h2v3h-2zM11 20h2v3h-2zM1 11h3v2H1zM20 11h3v2h-3zM4.2 5.6l1.4-1.4 2.1 2.1-1.4 1.4zM16.3 18.4l1.4-1.4 2.1 2.1-1.4 1.4zM4.2 18.4l2.1-2.1 1.4 1.4-2.1 2.1zM16.3 5.6l2.1-2.1 1.4 1.4-2.1 2.1z'] },
    { id: 'moon', cat: 'icon', label: 'Luna', vb: '0 0 24 24', paths: ['M14.5 2a10 10 0 1 0 7.5 16.2A8 8 0 0 1 14.5 2z'] },
    { id: 'camera', cat: 'icon', label: 'Cámara', vb: '0 0 24 24', rule: 'evenodd', paths: ['M3 7h4l2-2.5h6L17 7h4v12H3V7zm9 2.5a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9z'] },
    { id: 'pin', cat: 'icon', label: 'Ubicación', vb: '0 0 24 24', rule: 'evenodd', paths: ['M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7zm0 9.5a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z'] },
    { id: 'bell', cat: 'icon', label: 'Campana', vb: '0 0 24 24', paths: ['M12 22a2.2 2.2 0 0 0 2.2-2.2h-4.4A2.2 2.2 0 0 0 12 22zm7-6V11c0-3.1-1.6-5.6-4.5-6.3V4a2.5 2.5 0 0 0-5 0v.7C7.6 5.4 6 7.9 6 11v5l-2 2v1h16v-1l-2-2z'] },
    { id: 'leaf', cat: 'icon', label: 'Hoja', vb: '0 0 24 24', rule: 'evenodd', paths: ['M4 20C4 9 10 4 20 4c0 10-5 16-16 16zm2-2c4-3 7-6 9-10-4 2-7 5-9 10z'] },
    { id: 'bolt', cat: 'icon', label: 'Rayo', vb: '0 0 24 24', paths: ['M13 2 4 14h6l-1 8 9-12h-6l1-8z'] },
    { id: 'smile', cat: 'icon', label: 'Sonrisa', vb: '0 0 24 24', rule: 'evenodd', paths: ['M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM8.5 9a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zm7 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zM7.5 14.5h9a4.5 4.5 0 0 1-9 0z'] },

    // ----- Stickers (100 × 100) -----
    { id: 'burst', cat: 'sticker', label: 'Explosión', vb: '0 0 100 100', paths: [polyD(starPts(12, 50, 38))] },
    { id: 'badge', cat: 'sticker', label: 'Sello', vb: '0 0 100 100', paths: [polyD(starPts(16, 50, 43))] },
    { id: 'sparkle', cat: 'sticker', label: 'Destello', vb: '0 0 100 100', paths: [polyD(starPts(4, 50, 12))] },
    { id: 'speech', cat: 'sticker', label: 'Globo de diálogo', vb: '0 0 100 100', paths: ['M12 14h76a8 8 0 0 1 8 8v44a8 8 0 0 1-8 8H42L24 90v-16h-12a8 8 0 0 1-8-8V22a8 8 0 0 1 8-8z'] },
    { id: 'ribbon', cat: 'sticker', label: 'Cinta', vb: '0 0 100 100', paths: ['M4 30h92l-8 14 8 14H4l8-14z'] },
    { id: 'swoosh', cat: 'sticker', label: 'Trazo curvo', vb: '0 0 100 100', paths: ['M4 70C30 40 70 100 96 30L96 36C70 106 30 46 4 76Z'] },

    // ----- Marcos (100 × 100, con hueco) -----
    { id: 'frame-square', cat: 'frame', label: 'Marco cuadrado', vb: '0 0 100 100', rule: 'evenodd', paths: ['M4 4h92v92H4zM14 14v72h72V14z'] },
    { id: 'frame-circle', cat: 'frame', label: 'Marco circular', vb: '0 0 100 100', rule: 'evenodd', paths: ['M50 2a48 48 0 1 0 0 96 48 48 0 1 0 0-96zM50 12a38 38 0 1 0 0 76 38 38 0 1 0 0-76z'] },
    { id: 'frame-star', cat: 'frame', label: 'Marco estrella', vb: '0 0 100 100', rule: 'evenodd', paths: [polyD(starPts(5, 50, 40)) + polyD(starPts(5, 40, 32).map((p) => [p[0], p[1]]))] },
    { id: 'frame-arch', cat: 'frame', label: 'Marco arco', vb: '0 0 100 100', rule: 'evenodd', paths: ['M4 96V40C4 18 22 4 50 4s46 14 46 36v60zM16 96V42c0-16 14-28 34-28s34 12 34 28v54z'] }
  ];

  F.ASSET_BY_ID = {};
  F.ASSETS.forEach((a) => { F.ASSET_BY_ID[a.id] = a; });

  // Fuentes disponibles (Google Fonts y las del sistema). La clave es la que guarda cada elemento.
  F.FONT_OPTIONS = ['inter', 'montserrat', 'poppins', 'oswald', 'bebas', 'playfair', 'lora', 'merriweather', 'serif', 'pacifico', 'dancing', 'mono'];
})();
