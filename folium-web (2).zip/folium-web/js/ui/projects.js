/* Folium · proyectos: lista, abrir, duplicar, renombrar, eliminar y crear desde plantilla */
(function () {
  'use strict';
  const F = window.Folium, S = F.state, $ = F.$;
  const dialog = () => document.getElementById('projectsDialog');

  function fmtDate(ts) {
    try { return new Date(ts).toLocaleString('es', { dateStyle: 'medium', timeStyle: 'short' }); } catch (e) { return ''; }
  }

  function render() {
    const list = $('#projectList');
    if (!list) return;
    list.innerHTML = '';
    S.projects().forEach((p) => {
      const li = document.createElement('li');
      if (p.id === S.data.currentId) li.className = 'current';
      li.innerHTML = `<div class="meta"><strong>${F.esc(p.name)}</strong>
        <span>${p.canvas.width}×${p.canvas.height} · ${F.esc(fmtDate(p.updated))}${p.id === S.data.currentId ? ' · abierto' : ''}</span></div>
        <div class="acts">
          <button class="btn small" type="button" data-act="open" data-id="${p.id}">Abrir</button>
          <button class="btn small" type="button" data-act="dup" data-id="${p.id}">Duplicar</button>
          <button class="btn small" type="button" data-act="rename" data-id="${p.id}">Renombrar</button>
          <button class="btn small danger" type="button" data-act="del" data-id="${p.id}">Eliminar</button>
        </div>`;
      list.appendChild(li);
    });
    const tpl = $('#tplSelect');
    if (tpl && !tpl.options.length) {
      Object.keys(F.TEMPLATES).forEach((k) => {
        const o = document.createElement('option');
        o.value = k;
        o.textContent = F.TEMPLATES[k].label + ` (${F.TEMPLATES[k].width}×${F.TEMPLATES[k].height})`;
        tpl.appendChild(o);
      });
    }
  }

  function syncTitles() {
    const name = S.project() ? S.project().name : '';
    $('#docTitle').value = name;
    $('#docModeTitle').value = name;
    document.title = (name ? name + ' · ' : '') + 'Folium';
  }

  function bindTitle(input) {
    input.addEventListener('change', () => {
      const v = input.value.trim() || 'Diseño sin título';
      S.project().name = v;
      S.commit();
      syncTitles();
    });
  }

  function bindList() {
    const list = $('#projectList');
    if (!list) return;
    list.addEventListener('click', (e) => {
      const b = e.target.closest('button[data-act]');
      if (!b) return;
      const id = b.dataset.id;
      const act = b.dataset.act;
      if (act === 'open') { S.openProject(id); dialog().close(); F.toast('Proyecto abierto', '', 1400); }
      if (act === 'dup') { const c = S.duplicateProject(id); F.toast(c ? 'Proyecto duplicado' : 'No se pudo duplicar', c ? 'ok' : 'error'); render(); }
      if (act === 'rename') {
        const p = S.data.projects[id];
        const name = window.prompt('Nuevo nombre del proyecto:', p.name);
        if (name && name.trim()) { p.name = name.trim(); p.updated = Date.now(); S.save(); syncTitles(); render(); }
      }
      if (act === 'del') {
        const p = S.data.projects[id];
        if (!window.confirm(`¿Eliminar "${p.name}"? Esta acción no se puede deshacer.`)) return;
        if (S.deleteProject(id)) F.toast('Proyecto eliminado', '', 1800);
        else F.toast('Debe quedar al menos un proyecto', 'error');
        render();
      }
    });
  }

  function init() {
    bindTitle($('#docTitle'));
    bindTitle($('#docModeTitle'));
    bindList();

    $('#newBlank').addEventListener('click', () => {
      S.addProject(null, null);
      dialog().close();
      F.toast('Nuevo diseño en blanco', 'ok');
    });
    const sizeSel = $('#sizeSelect');
    if (sizeSel && !sizeSel.options.length) {
      F.SIZE_PRESETS.forEach((p) => { const o = document.createElement('option'); o.value = p.id; o.textContent = p.label; sizeSel.appendChild(o); });
    }
    $('#newSized').addEventListener('click', () => {
      const preset = F.SIZE_PRESETS.find((p) => p.id === $('#sizeSelect').value) || F.SIZE_PRESETS[0];
      const p = S.addProject(null, null);
      p.canvas.width = preset.w;
      p.canvas.height = preset.h;
      if ($('#newTransparent').checked) p.canvas.background = 'transparent';
      S.commit();
      dialog().close();
      F.toast('Nuevo diseño: ' + preset.label, 'ok');
    });
    $('#newFromTpl').addEventListener('click', () => {
      const id = $('#tplSelect').value;
      S.addProject(null, id);
      dialog().close();
      F.toast('Nuevo diseño desde plantilla', 'ok');
    });

    F.on('project', () => { syncTitles(); render(); });
    F.on('change', () => { syncTitles(); });
    syncTitles();
  }

  F.projects = { init, render: () => render(), syncTitles: () => syncTitles() };
})();
