/* Folium · panel de elementos: formas, líneas, presets de texto, biblioteca de assets y fondos degradados */
(function () {
  'use strict';
  const F = window.Folium, $ = F.$;

  const PRESETS = {
    title: { size: 96, weight: 700, text: 'Título', w: 760, h: 130, name: 'Título' },
    sub: { size: 56, weight: 600, text: 'Subtítulo', w: 640, h: 86, name: 'Subtítulo' },
    body: { size: 30, weight: 400, text: 'Escribe aquí el texto del cuerpo.', w: 560, h: 120, name: 'Cuerpo' }
  };

  const svg = (inner) => `<svg viewBox="0 0 24 24" aria-hidden="true">${inner}</svg>`;

  function shapeIcon(name) {
    if (name === 'rect') return svg('<rect x="3" y="5" width="18" height="14" rx="3" fill="currentColor"/>');
    if (name === 'ellipse') return svg('<circle cx="12" cy="12" r="8.5" fill="currentColor"/>');
    if (name === 'triangle') return svg('<polygon points="12,3.5 21,20.5 3,20.5" fill="currentColor"/>');
    const pts = F.shapePoints(name).map((p) => `${(3 + p[0] * 0.18).toFixed(2)},${(3 + p[1] * 0.18).toFixed(2)}`).join(' ');
    return svg(`<polygon points="${pts}" fill="currentColor"/>`);
  }

  function lineIcon(thick, dash, arrow) {
    const x1 = arrow === 'start' || arrow === 'both' ? 9 : 3;
    const x2 = arrow === 'end' || arrow === 'both' ? 15 : 21;
    const dashAttr = dash === 'dashed' ? ' stroke-dasharray="4 2.5"' : dash === 'dotted' ? ' stroke-dasharray="0.6 3" stroke-linecap="round"' : '';
    let inner = `<line x1="${x1}" y1="12" x2="${x2}" y2="12" stroke="currentColor" stroke-width="${thick}"${dashAttr}/>`;
    if (arrow === 'end' || arrow === 'both') inner += '<polygon points="14,7 19,12 14,17" fill="currentColor"/>';
    if (arrow === 'start' || arrow === 'both') inner += '<polygon points="10,7 5,12 10,17" fill="currentColor"/>';
    return svg(inner);
  }

  function assetIcon(a) {
    const vb = a.vb;
    const paths = a.paths.map((d) => `<path d="${d}" fill="currentColor"${a.rule ? ` fill-rule="${a.rule}"` : ''}/>`).join('');
    return `<svg viewBox="${vb}" aria-hidden="true">${paths}</svg>`;
  }

  function tile(attrs, icon, label) {
    return `<button type="button" class="tile" ${attrs} title="${F.esc(label)}" aria-label="Agregar ${F.esc(label)}">` +
      `<span class="tile-ico">${icon}</span><span class="tile-t">${F.esc(label)}</span></button>`;
  }

  function build() {
    const shapes = $('#shapeGrid'), lines = $('#lineGrid'), texts = $('#textPresets');
    if (!shapes || !lines || !texts) return;

    const basic = [['rect', 'Rectángulo'], ['ellipse', 'Círculo'], ['triangle', 'Triángulo']];
    shapes.innerHTML = basic.map(([t, l]) => tile(`data-add="${t}"`, shapeIcon(t), l)).join('') +
      Object.keys(F.SHAPES).map((k) => tile(`data-add="poly" data-shape="${k}"`, shapeIcon(k), F.SHAPES[k])).join('');

    const styles = [
      ['Línea fina', 3, 'solid', 'none'], ['Línea gruesa', 10, 'solid', 'none'],
      ['Punteada', 4, 'dotted', 'none'], ['Discontinua', 4, 'dashed', 'none'],
      ['Flecha', 4, 'solid', 'end'], ['Doble flecha', 4, 'solid', 'both']
    ];
    lines.innerHTML = styles.map(([label, h, dash, arrow]) =>
      tile(`data-add="line" data-h="${h}" data-dash="${dash}" data-arrow="${arrow}"`, lineIcon(Math.min(Math.max(h, 3), 4), dash, arrow), label)
    ).join('');

    texts.innerHTML = [
      ['title', 'Título', 'font-size:22px;font-weight:700'],
      ['sub', 'Subtítulo', 'font-size:16px;font-weight:600'],
      ['body', 'Cuerpo de texto', 'font-size:13px;font-weight:400']
    ].map(([k, label, css]) =>
      `<button type="button" class="tpreset" data-add="text" data-preset="${k}" aria-label="Agregar ${label}">` +
      `<span style="${css}">${label}</span></button>`
    ).join('');

    // Biblioteca: iconos, stickers y marcos
    const byCat = (cat) => F.ASSETS.filter((a) => a.cat === cat);
    const fill = (box, cat) => {
      const el = $(box);
      if (!el) return;
      el.innerHTML = byCat(cat).map((a) => tile(`data-asset="${a.id}"`, assetIcon(a), a.label)).join('');
    };
    fill('#iconGrid', 'icon');
    fill('#stickerGrid', 'sticker');
    fill('#frameGrid', 'frame');

    // Fondos degradados: muestras que añaden un rectángulo del tamaño del lienzo
    const bg = $('#bgGrid');
    if (bg) {
      bg.innerHTML = Object.keys(F.GRADIENTS).map((k) => {
        const g = F.GRADIENTS[k];
        return `<button type="button" data-bg="${k}" title="Fondo ${F.esc(g.label)}" aria-label="Fondo ${F.esc(g.label)}">` +
          `<span style="background:linear-gradient(135deg, ${g.c1}, ${g.c2})"></span></button>`;
      }).join('');
    }

    [shapes, lines, texts, $('#iconGrid'), $('#stickerGrid'), $('#frameGrid'), bg].forEach((box) => {
      if (!box) return;
      box.addEventListener('click', (e) => {
        const b = e.target.closest('[data-add], [data-asset], [data-bg]');
        if (!b) return;
        if (b.dataset.bg) {
          F.actions.addBackground(b.dataset.bg);
        } else if (b.dataset.asset) {
          F.actions.addAsset(b.dataset.asset);
        } else {
          const type = b.dataset.add;
          const props = {};
          if (type === 'poly') { props.shape = b.dataset.shape; props.name = F.SHAPES[props.shape]; }
          if (type === 'line') {
            props.h = Number(b.dataset.h) || 4;
            props.dash = b.dataset.dash || 'solid';
            props.arrow = b.dataset.arrow || 'none';
          }
          if (type === 'text') Object.assign(props, PRESETS[b.dataset.preset] || {});
          F.actions.add(type, props);
        }
        if (F.isMobile()) document.getElementById('app').classList.remove('show-left');
      });
    });
  }

  F.elementsPanel = { build };
})();
