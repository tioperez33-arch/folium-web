/* Folium · Inicio: plantillas y diseños recientes con miniaturas */
(function () {
  'use strict';
  const F = window.Folium, S = F.state, $ = F.$;

  const thumb = (canvas) => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(F.exp.svgFor(canvas));

  function card(title, meta, src, onClick) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'card';
    b.innerHTML = `<span class="thumb">${src ? `<img alt="" src="${src}">` : ''}</span>` +
      `<span class="card-t">${F.esc(title)}</span><span class="card-m">${F.esc(meta)}</span>`;
    b.addEventListener('click', onClick);
    return b;
  }

  function render() {
    const tplBox = $('#homeTemplates'), recBox = $('#homeRecent');
    if (!tplBox || !S.data) return;
    tplBox.innerHTML = '';
    recBox.innerHTML = '';

    Object.keys(F.TEMPLATES).forEach((k) => {
      const t = F.TEMPLATES[k];
      const canvas = { width: t.width, height: t.height, background: t.background, elements: t.make() };
      tplBox.appendChild(card(t.label, `${t.width} × ${t.height}`, thumb(canvas), () => {
        S.addProject(null, k);
        F.setView('canvas');
        F.toast('Nuevo diseño desde plantilla', 'ok');
      }));
    });

    const recent = S.projects().slice(0, 8);
    if (!recent.length) {
      recBox.innerHTML = '<p class="hint">Aún no tienes diseños. Elige una plantilla para empezar.</p>';
      return;
    }
    recent.forEach((p) => {
      const when = new Date(p.updated).toLocaleDateString('es', { day: 'numeric', month: 'short' });
      recBox.appendChild(card(p.name, `${p.canvas.width} × ${p.canvas.height} · ${when}`, thumb(p.canvas), () => {
        S.openProject(p.id);
        F.setView('canvas');
      }));
    });
  }

  function init() {
    $('#homeNew').addEventListener('click', () => { S.addProject(null, null); F.setView('canvas'); });
    $('#homeNewDoc').addEventListener('click', () => { S.addProject(null, null); F.setView('doc'); });
    $('#homeAll').addEventListener('click', () => { F.projects.render(); document.getElementById('projectsDialog').showModal(); });
  }

  F.home = { init, render };
})();
