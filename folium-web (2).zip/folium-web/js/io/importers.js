/* ==========================================================
   Folium · importar y exportar documentos
   - PDF: primera página como bloques de texto en su posición original.
   - Word (.docx), texto (.txt, .md) y HTML: párrafos y títulos al modo documento.
     Google Docs se importa descargándolo desde Google Docs como Word, PDF, HTML o texto.
   - JSON: respaldo completo del proyecto del lienzo.
   Las librerías (pdf.js, JSZip) se cargan solo cuando hacen falta.
   Expone Folium.io.
   ========================================================== */

(() => {
  'use strict';
  const F = window.Folium;

  const PDFJS_URL = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
  const PDFJS_WORKER_URL = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  const JSZIP_URL = 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js';
  const WORD_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';

  // PDF usa puntos (1/72 in); el lienzo usa píxeles a 96 ppp
  const PT_TO_PX = 96 / 72;

  const loadedScripts = {};

  function loadScript(url) {
    if (!loadedScripts[url]) {
      loadedScripts[url] = new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = url;
        s.onload = resolve;
        s.onerror = () => {
          delete loadedScripts[url];
          reject(new Error('No se pudo cargar una librería necesaria. Revisa tu conexión.'));
        };
        document.head.appendChild(s);
      });
    }
    return loadedScripts[url];
  }

  function randomId() {
    return 'p' + Math.random().toString(36).slice(2, 9);
  }

  function escapeHtml(text) {
    return text.replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  // ---------- PDF ----------
  async function importPdf(file) {
    await loadScript(PDFJS_URL);
    if (!window.pdfjsLib) throw new Error('pdf.js no está disponible');
    window.pdfjsLib.GlobalWorkerOptions.workerSrc = PDFJS_WORKER_URL;

    const data = new Uint8Array(await file.arrayBuffer());
    const pdf = await window.pdfjsLib.getDocument({ data }).promise;
    const page = await pdf.getPage(1);
    const viewport = page.getViewport({ scale: PT_TO_PX });
    const content = await page.getTextContent();

    const elements = [];
    content.items.forEach((item) => {
      if (!item.str || !item.str.trim()) return;

      // La matriz de texto da la posición de la línea base, con origen abajo a la izquierda
      const [x, baseY] = viewport.convertToViewportPoint(item.transform[4], item.transform[5]);
      const size = Math.max(6, Math.hypot(item.transform[2], item.transform[3]) * PT_TO_PX);

      elements.push({
        id: randomId(),
        type: 'text',
        x: Math.round(x),
        y: Math.round(baseY - size * 0.85),
        w: Math.max(20, Math.round(item.width * PT_TO_PX)),
        h: Math.round(size * 1.25),
        fill: '#0E1330',
        text: item.str,
        size: Math.round(size),
        weight: 400
      });
    });

    return {
      title: file.name.replace(/\.pdf$/i, ''),
      width: Math.round(viewport.width),
      height: Math.round(viewport.height),
      elements,
      pages: pdf.numPages
    };
  }

  // ---------- Word ----------
  async function importDocx(file) {
    await loadScript(JSZIP_URL);
    if (!window.JSZip) throw new Error('JSZip no está disponible');

    const zip = await window.JSZip.loadAsync(file);
    const entry = zip.file('word/document.xml');
    if (!entry) throw new Error('El archivo no parece un documento de Word (.docx)');

    const xml = await entry.async('string');
    const parsed = new DOMParser().parseFromString(xml, 'application/xml');
    const paragraphs = [...parsed.getElementsByTagNameNS(WORD_NS, 'p')];

    const html = paragraphs.map((p) => {
      const pStyle = p.getElementsByTagNameNS(WORD_NS, 'pStyle')[0];
      const style = pStyle ? pStyle.getAttributeNS(WORD_NS, 'val') || '' : '';
      const text = [...p.getElementsByTagNameNS(WORD_NS, 't')].map((t) => t.textContent).join('');
      if (!text.trim()) return '';
      const safe = escapeHtml(text);
      return /heading|título|title/i.test(style) ? `<h2>${safe}</h2>` : `<p>${safe}</p>`;
    }).filter(Boolean).join('\n');

    if (!html) throw new Error('No encontré texto en el documento');

    return {
      title: file.name.replace(/\.docx$/i, ''),
      html
    };
  }

  // ---------- Texto plano (.txt, .md) ----------
  // Un salto de línea doble separa párrafos; uno simple se conserva como salto
  async function importText(file) {
    const text = await file.text();
    const html = text
      .split(/\r?\n\s*\r?\n/)
      .map((block) => block.trim())
      .filter(Boolean)
      .map((block) => `<p>${escapeHtml(block).replace(/\r?\n/g, '<br>')}</p>`)
      .join('\n');

    if (!html) throw new Error('El archivo de texto está vacío');
    return { title: file.name.replace(/\.(txt|md)$/i, ''), html };
  }

  // ---------- HTML (incluye la exportación de Google Docs) ----------
  // Solo leemos el texto de títulos, párrafos y listas. No ejecutamos ni copiamos scripts ni estilos.
  async function importHtml(file) {
    const raw = await file.text();
    const parsed = new DOMParser().parseFromString(raw, 'text/html');

    const blocks = [...parsed.body.querySelectorAll('h1, h2, h3, p, li')]
      // Un <li> que contiene <p> ya se cuenta por su párrafo
      .filter((node) => !(node.tagName === 'LI' && node.querySelector('p')));

    const html = blocks.map((node) => {
      const text = node.textContent.replace(/\s+/g, ' ').trim();
      if (!text) return '';
      const safe = escapeHtml(text);
      if (/^H[1-3]$/.test(node.tagName)) return `<h2>${safe}</h2>`;
      if (node.tagName === 'LI') return `<p>• ${safe}</p>`;
      return `<p>${safe}</p>`;
    }).filter(Boolean).join('\n');

    if (!html) throw new Error('No encontré texto en el archivo HTML');
    return { title: file.name.replace(/\.html?$/i, ''), html };
  }

  // ---------- Proyecto JSON ----------
  function isValidProject(data) {
    if (!data || typeof data !== 'object') return false;
    const d = data.doc;
    if (!d || typeof d.width !== 'number' || typeof d.height !== 'number') return false;
    if (!Array.isArray(data.elements)) return false;
    return data.elements.every((e) => e && typeof e.id === 'string' && typeof e.type === 'string');
  }

  async function readProjectFile(file) {
    const text = await file.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch (err) {
      throw new Error('El archivo no es un JSON válido');
    }
    if (!isValidProject(data)) throw new Error('El archivo no es un proyecto de Folium');
    return { doc: data.doc, elements: data.elements };
  }

  function downloadJson(data, filename) {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  window.Folium = window.Folium || {};
  window.Folium.io = {
    importPdf,
    importDocx,
    importText,
    importHtml,
    readProjectFile,
    downloadJson,
    escapeHtml
  };
})();

// Imagen soltada o subida: se lee como data URL y se mide para conservar su proporción
(() => {
  const F = window.Folium;
  F.io.importImage = async (file) => {
    if (!file.type.startsWith('image/')) throw new Error('El archivo no es una imagen');
    if (file.size > 4 * 1024 * 1024) throw new Error('La imagen supera 4 MB');
    const src = await F.readAs(file, 'dataurl');
    const img = await F.loadImage(src);
    const scale = Math.min(1, 480 / img.width);
    return { src, w: Math.round(img.width * scale), h: Math.round(img.height * scale) };
  };
})();
