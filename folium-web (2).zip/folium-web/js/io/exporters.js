/* Folium · exportación: PNG, PDF (vectorial con imágenes rasterizadas cuando hay efectos), SVG,
   Word (.docx), HTML, texto y proyecto JSON */
(function () {
  'use strict';
  const F = window.Folium, S = F.state;
  const PT = 0.75; // 1 px del lienzo (96 ppp) = 0.75 pt
  const K = 0.5523; // constante de Bézier para círculos y esquinas redondeadas

  F.exp = {};
  const measureCtx = document.createElement('canvas').getContext('2d');

  // ----- Utilidades -----
  function fontStr(el) {
    return `${el.italic ? 'italic ' : ''}${el.weight || 400} ${el.size}px ${F.fontOf(el.font).css}`;
  }

  function wrap(text, maxW, font) {
    measureCtx.font = font;
    const out = [];
    String(text || '').split('\n').forEach((par) => {
      const words = par.split(/(\s+)/);
      let line = '';
      words.forEach((w) => {
        const test = line + w;
        if (line.trim() && measureCtx.measureText(test).width > maxW) {
          out.push(line.trimEnd());
          line = w.trimStart();
        } else {
          line = test;
        }
      });
      out.push(line);
    });
    return out;
  }

  const hasFilt = (f) => !!f && (f.br !== 100 || f.ct !== 100 || f.sa !== 100 || f.bl || f.gs || f.se);
  const filterStr = (f) => [
    `brightness(${f.br}%)`, `contrast(${f.ct}%)`, `saturate(${f.sa}%)`,
    `blur(${f.bl}px)`, `grayscale(${f.gs}%)`, `sepia(${f.se}%)`
  ].join(' ');

  // Ángulo de degradado de CSS (0° = hacia arriba) convertido a fracciones de la caja
  function gradVec(g) {
    const r = (g.a * Math.PI) / 180;
    return { dx: Math.sin(r), dy: -Math.cos(r) };
  }

  // ----- Geometría para el lienzo 2D -----
  function roundRect(ctx, x, y, w, h, r) {
    r = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function polyPath(ctx, pts) {
    ctx.beginPath();
    pts.forEach((p, i) => { if (i) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]); });
    ctx.closePath();
  }

  function elPoly(el) {
    return F.shapePoints(el.shape).map((p) => [el.x + (p[0] / 100) * el.w, el.y + (p[1] / 100) * el.h]);
  }

  // Máscara de forma para imágenes (misma lógica que el lienzo en pantalla)
  function maskPath(ctx, el) {
    const m = el.mask;
    if (m === 'ellipse') {
      ctx.beginPath();
      ctx.ellipse(el.x + el.w / 2, el.y + el.h / 2, el.w / 2, el.h / 2, 0, 0, Math.PI * 2);
    } else if (m === 'rounded') {
      roundRect(ctx, el.x, el.y, el.w, el.h, Math.min(el.w, el.h) * 0.18);
    } else {
      polyPath(ctx, elPoly(Object.assign({}, el, { shape: m })));
    }
  }

  // Rotación y volteo alrededor del centro del elemento
  function applyTransform(ctx, el) {
    const cx = el.x + el.w / 2, cy = el.y + el.h / 2;
    ctx.translate(cx, cy);
    if (el.rot) ctx.rotate((el.rot * Math.PI) / 180);
    if (el.fx || el.fy) ctx.scale(el.fx ? -1 : 1, el.fy ? -1 : 1);
    ctx.translate(-cx, -cy);
  }

  // Relleno con degradado dentro de la caja (x, y, w, h)
  function fillStyle(ctx, el, x, y, w, h) {
    if (!el.grad) return el.fill;
    const v = gradVec(el.grad);
    const cx = x + w / 2, cy = y + h / 2;
    const half = Math.max(w, h) / 2;
    const g = ctx.createLinearGradient(cx - v.dx * half, cy - v.dy * half, cx + v.dx * half, cy + v.dy * half);
    g.addColorStop(0, el.grad.c1);
    g.addColorStop(1, el.grad.c2);
    return g;
  }

  function setShadow(ctx, el) {
    if (!el.shadow) return;
    ctx.shadowColor = el.shadow.c;
    ctx.shadowOffsetX = el.shadow.x;
    ctx.shadowOffsetY = el.shadow.y;
    ctx.shadowBlur = el.shadow.b;
  }

  function fillStroke(ctx, el, fill) {
    ctx.fillStyle = fill;
    ctx.fill();
    if (el.stroke) {
      ctx.shadowColor = 'transparent';
      ctx.lineWidth = el.stroke.w;
      ctx.strokeStyle = el.stroke.c;
      ctx.stroke();
    }
  }

  function drawLine(ctx, el) {
    const head = Math.max(12, el.h * 3), a = el.arrow || 'none', y = el.y + el.h / 2;
    const x0 = el.x + (a === 'start' || a === 'both' ? head * 0.8 : 0);
    const x1 = el.x + el.w - (a === 'end' || a === 'both' ? head * 0.8 : 0);
    ctx.strokeStyle = el.fill;
    ctx.lineWidth = el.h;
    ctx.lineCap = 'butt';
    ctx.setLineDash(el.dash === 'dashed' ? [el.h * 3, el.h * 2] : el.dash === 'dotted' ? [el.h, el.h * 2] : []);
    ctx.beginPath();
    ctx.moveTo(x0, y);
    ctx.lineTo(x1, y);
    ctx.stroke();
    ctx.setLineDash([]);
    const tri = (base, tip) => {
      ctx.beginPath();
      ctx.moveTo(base, y - head / 2);
      ctx.lineTo(tip, y);
      ctx.lineTo(base, y + head / 2);
      ctx.closePath();
      ctx.fillStyle = el.fill;
      ctx.fill();
    };
    if (a === 'end' || a === 'both') tri(el.x + el.w - head, el.x + el.w);
    if (a === 'start' || a === 'both') tri(el.x + head, el.x);
  }

  function drawText(ctx, el) {
    const font = fontStr(el);
    ctx.font = font;
    ctx.textBaseline = 'top';
    const lines = wrap(el.text, el.w, font);
    const lh = el.size * 1.2;
    const fill = fillStyle(ctx, el, el.x, el.y, el.w, el.h);
    lines.forEach((ln, i) => {
      const tw = ctx.measureText(ln).width;
      let x = el.x;
      if (el.align === 'center') x = el.x + (el.w - tw) / 2;
      if (el.align === 'right') x = el.x + el.w - tw;
      const y = el.y + i * lh;
      if (el.hl) {
        ctx.save();
        ctx.shadowColor = 'transparent';
        ctx.fillStyle = el.hl;
        ctx.fillRect(x - 4, y, tw + 8, lh);
        ctx.restore();
      }
      ctx.fillStyle = fill;
      ctx.fillText(ln, x, y);
      if (el.stroke) {
        ctx.save();
        ctx.shadowColor = 'transparent';
        ctx.lineWidth = el.stroke.w;
        ctx.strokeStyle = el.stroke.c;
        ctx.strokeText(ln, x, y);
        ctx.restore();
      }
    });
  }

  function drawAsset(ctx, el) {
    const a = F.ASSET_BY_ID[el.aid];
    if (!a) return;
    const p = a.paths.map((d) => [d]);
    const vb = a.vb.split(/\s+/).map(Number);
    ctx.save();
    ctx.translate(el.x, el.y);
    ctx.scale(el.w / vb[2], el.h / vb[3]);
    ctx.translate(-vb[0], -vb[1]);
    const fill = fillStyle(ctx, el, vb[0], vb[1], vb[2], vb[3]);
    p.forEach(([d]) => {
      const path = new Path2D(d);
      ctx.fillStyle = fill;
      ctx.fill(path, a.rule === 'evenodd' ? 'evenodd' : 'nonzero');
      if (el.stroke) {
        ctx.lineWidth = el.stroke.w * (vb[2] / el.w);
        ctx.strokeStyle = el.stroke.c;
        ctx.stroke(path);
      }
    });
    ctx.restore();
  }

  function drawCover(ctx, img, x, y, w, h) {
    const s = Math.max(w / img.width, h / img.height);
    const sw = w / s, sh = h / s;
    ctx.drawImage(img, (img.width - sw) / 2, (img.height - sh) / 2, sw, sh, x, y, w, h);
  }

  async function drawImage(ctx, el) {
    const img = await F.loadImage(el.src);
    ctx.save();
    if (el.mask && el.mask !== 'none') { maskPath(ctx, el); ctx.clip(); }
    if (hasFilt(el.filt)) ctx.filter = filterStr(el.filt);
    drawCover(ctx, img, el.x, el.y, el.w, el.h);
    ctx.restore();
  }

  // Dibuja un elemento en el lienzo 2D (con rotación, volteo, efectos y opacidad)
  async function drawEl(ctx, el) {
    ctx.save();
    ctx.globalAlpha = el.op == null ? 1 : el.op;
    applyTransform(ctx, el);
    setShadow(ctx, el);
    if (el.type === 'rect') {
      roundRect(ctx, el.x, el.y, el.w, el.h, el.radius || 0);
      fillStroke(ctx, el, fillStyle(ctx, el, el.x, el.y, el.w, el.h));
    }
    if (el.type === 'ellipse') {
      ctx.beginPath();
      ctx.ellipse(el.x + el.w / 2, el.y + el.h / 2, el.w / 2, el.h / 2, 0, 0, Math.PI * 2);
      fillStroke(ctx, el, fillStyle(ctx, el, el.x, el.y, el.w, el.h));
    }
    if (el.type === 'triangle') {
      polyPath(ctx, [[el.x + el.w / 2, el.y], [el.x + el.w, el.y + el.h], [el.x, el.y + el.h]]);
      fillStroke(ctx, el, fillStyle(ctx, el, el.x, el.y, el.w, el.h));
    }
    if (el.type === 'poly') {
      polyPath(ctx, elPoly(el));
      fillStroke(ctx, el, fillStyle(ctx, el, el.x, el.y, el.w, el.h));
    }
    if (el.type === 'line') drawLine(ctx, el);
    if (el.type === 'asset') drawAsset(ctx, el);
    if (el.type === 'text') drawText(ctx, el);
    if (el.type === 'image') await drawImage(ctx, el);
    ctx.restore();
  }

  // ----- PNG -----
  // Imagen del lienzo. flat=true rellena el fondo transparente con blanco (necesario para JPG)
  F.exp.raster = async (scale, mime, quality, flat) => {
    const c = S.canvas();
    const k = scale || 2;
    const cv = document.createElement('canvas');
    cv.width = c.width * k;
    cv.height = c.height * k;
    const ctx = cv.getContext('2d');
    ctx.scale(k, k);
    if (c.background !== 'transparent' || flat) {
      ctx.fillStyle = c.background === 'transparent' ? '#FFFFFF' : c.background;
      ctx.fillRect(0, 0, c.width, c.height);
    }
    for (const el of c.elements) { if (!el.hidden) await drawEl(ctx, el); }
    return new Promise((res) => cv.toBlob(res, mime, quality));
  };
  F.exp.png = (scale) => F.exp.raster(scale, 'image/png');
  F.exp.jpg = (scale, quality) => F.exp.raster(scale, 'image/jpeg', quality, true);

  // Exportación a medida desde el diálogo (formato, escala y calidad)
  F.exp.custom = async (fmt, scale, quality) => {
    const name = F.safeName(S.project().name);
    try {
      if (fmt === 'jpg') F.download(await F.exp.jpg(scale, quality), name + '.jpg', 'image/jpeg');
      else F.download(await F.exp.png(scale), name + '.png', 'image/png');
      F.toast(`Imagen ${fmt.toUpperCase()} exportada (${scale}×)`, 'ok');
    } catch (err) {
      F.toast('No se pudo exportar: ' + (err.message || 'error'), 'error', 5000);
    }
  };

  // ----- SVG -----
  // Genera el SVG de un lienzo; sirve para exportar y para las miniaturas de Inicio
  F.exp.svgFor = (c) => {
    const defs = [], parts = [];
    const esc = F.esc;
    const tf = (el) => {
      const cx = el.x + el.w / 2, cy = el.y + el.h / 2;
      const t = [];
      if (el.rot) t.push(`rotate(${el.rot} ${cx} ${cy})`);
      if (el.fx || el.fy) t.push(`translate(${cx} ${cy}) scale(${el.fx ? -1 : 1} ${el.fy ? -1 : 1}) translate(${-cx} ${-cy})`);
      return t.length ? ` transform="${t.join(' ')}"` : '';
    };
    const gradRef = (el) => {
      if (!el.grad) return null;
      const id = 'g-' + el.id, v = gradVec(el.grad);
      defs.push(`<linearGradient id="${id}" x1="${(0.5 - v.dx / 2).toFixed(3)}" y1="${(0.5 - v.dy / 2).toFixed(3)}" x2="${(0.5 + v.dx / 2).toFixed(3)}" y2="${(0.5 + v.dy / 2).toFixed(3)}"><stop offset="0" stop-color="${el.grad.c1}"/><stop offset="1" stop-color="${el.grad.c2}"/></linearGradient>`);
      return `url(#${id})`;
    };
    const stroke = (el) => (el.stroke ? ` stroke="${el.stroke.c}" stroke-width="${el.stroke.w}" stroke-linejoin="round"` : '');
    c.elements.forEach((el) => {
      if (el.hidden) return;
      const cx = el.x + el.w / 2, cy = el.y + el.h / 2;
      const op = el.op == null || el.op === 1 ? '' : ` opacity="${el.op}"`;
      let extra = op + tf(el);
      if (el.shadow) {
        const id = 's-' + el.id;
        defs.push(`<filter id="${id}" x="-50%" y="-50%" width="200%" height="200%"><feDropShadow dx="${el.shadow.x}" dy="${el.shadow.y}" stdDeviation="${el.shadow.b / 2}" flood-color="${el.shadow.c}"/></filter>`);
        extra += ` filter="url(#${id})"`;
      }
      const fillRef = gradRef(el);
      if (el.type === 'rect') parts.push(`<rect x="${el.x}" y="${el.y}" width="${el.w}" height="${el.h}" rx="${el.radius || 0}" fill="${fillRef || el.fill}"${stroke(el)}${extra}/>`);
      if (el.type === 'ellipse') parts.push(`<ellipse cx="${cx}" cy="${cy}" rx="${el.w / 2}" ry="${el.h / 2}" fill="${fillRef || el.fill}"${stroke(el)}${extra}/>`);
      if (el.type === 'triangle') parts.push(`<polygon points="${el.x + el.w / 2},${el.y} ${el.x + el.w},${el.y + el.h} ${el.x},${el.y + el.h}" fill="${fillRef || el.fill}"${stroke(el)}${extra}/>`);
      if (el.type === 'poly') parts.push(`<polygon points="${elPoly(el).map((p) => p[0].toFixed(2) + ',' + p[1].toFixed(2)).join(' ')}" fill="${fillRef || el.fill}"${stroke(el)}${extra}/>`);
      if (el.type === 'asset') {
        const a = F.ASSET_BY_ID[el.aid];
        if (a) {
          const vb = a.vb.split(/\s+/).map(Number);
          const paths = a.paths.map((d) => `<path d="${d}" fill="${fillRef || el.fill}"${a.rule ? ` fill-rule="${a.rule}"` : ''}${stroke(el)}/>`).join('');
          parts.push(`<g${extra}><g transform="translate(${el.x} ${el.y}) scale(${el.w / vb[2]} ${el.h / vb[3]}) translate(${-vb[0]} ${-vb[1]})">${paths}</g></g>`);
        }
      }
      if (el.type === 'line') {
        const head = Math.max(12, el.h * 3), a = el.arrow || 'none', y = cy;
        const x0 = el.x + (a === 'start' || a === 'both' ? head * 0.8 : 0);
        const x1 = el.x + el.w - (a === 'end' || a === 'both' ? head * 0.8 : 0);
        const dash = el.dash === 'dashed' ? ` stroke-dasharray="${el.h * 3} ${el.h * 2}"` : el.dash === 'dotted' ? ` stroke-dasharray="${el.h} ${el.h * 2}"` : '';
        parts.push(`<line x1="${x0}" y1="${y}" x2="${x1}" y2="${y}" stroke="${el.fill}" stroke-width="${el.h}"${dash}${extra}/>`);
        if (a === 'end' || a === 'both') parts.push(`<polygon points="${el.x + el.w - head},${y - head / 2} ${el.x + el.w},${y} ${el.x + el.w - head},${y + head / 2}" fill="${el.fill}"${extra}/>`);
        if (a === 'start' || a === 'both') parts.push(`<polygon points="${el.x + head},${y - head / 2} ${el.x},${y} ${el.x + head},${y + head / 2}" fill="${el.fill}"${extra}/>`);
      }
      if (el.type === 'image') {
        let clip = '';
        if (el.mask && el.mask !== 'none') {
          const id = 'm-' + el.id;
          let shape;
          if (el.mask === 'ellipse') shape = `<ellipse cx="${cx}" cy="${cy}" rx="${el.w / 2}" ry="${el.h / 2}"/>`;
          else if (el.mask === 'rounded') shape = `<rect x="${el.x}" y="${el.y}" width="${el.w}" height="${el.h}" rx="${Math.min(el.w, el.h) * 0.18}"/>`;
          else shape = `<polygon points="${elPoly(Object.assign({}, el, { shape: el.mask })).map((p) => p[0].toFixed(2) + ',' + p[1].toFixed(2)).join(' ')}"/>`;
          defs.push(`<clipPath id="${id}">${shape}</clipPath>`);
          clip = ` clip-path="url(#${id})"`;
        }
        parts.push(`<image href="${esc(el.src)}" x="${el.x}" y="${el.y}" width="${el.w}" height="${el.h}" preserveAspectRatio="xMidYMid slice"${clip}${extra}/>`);
      }
      if (el.type === 'text') {
        const f = F.fontOf(el.font);
        const lines = wrap(el.text, el.w, fontStr(el));
        const anchor = el.align === 'center' ? 'middle' : el.align === 'right' ? 'end' : 'start';
        const x = anchor === 'middle' ? el.x + el.w / 2 : anchor === 'end' ? el.x + el.w : el.x;
        if (el.hl) parts.push(`<rect x="${el.x}" y="${el.y}" width="${el.w}" height="${lines.length * el.size * 1.2}" fill="${el.hl}"${extra}/>`);
        const tspans = lines.map((ln, i) => `<tspan x="${x}" dy="${i === 0 ? el.size : el.size * 1.2}">${esc(ln)}</tspan>`).join('');
        const fill = fillRef || el.fill;
        parts.push(`<text x="${x}" y="${el.y}" font-family="${esc(f.css)}" font-size="${el.size}" font-weight="${el.weight}" font-style="${el.italic ? 'italic' : 'normal'}" text-anchor="${anchor}" fill="${fill}"${stroke(el)}${extra}>${tspans}</text>`);
      }
    });
    return `<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${c.width}" height="${c.height}" viewBox="0 0 ${c.width} ${c.height}">` +
      (defs.length ? `<defs>${defs.join('')}</defs>` : '') +
      (c.background === 'transparent' ? '' : `<rect width="${c.width}" height="${c.height}" fill="${c.background}"/>`) + parts.join('') + '</svg>';
  };
  F.exp.svg = () => F.exp.svgFor(S.canvas());

  // ----- PDF -----
  const enc = (str) => {
    const out = new Uint8Array(str.length);
    for (let i = 0; i < str.length; i++) out[i] = str.charCodeAt(i) & 255;
    return out;
  };

  function pdfFont(el) {
    const fam = F.fontOf(el.font).pdf;
    const bold = el.weight >= 600, italic = !!el.italic;
    const table = {
      Helvetica: ['Helvetica', 'Helvetica-Bold', 'Helvetica-Oblique', 'Helvetica-BoldOblique'],
      Times: ['Times-Roman', 'Times-Bold', 'Times-Italic', 'Times-BoldItalic'],
      Courier: ['Courier', 'Courier-Bold', 'Courier-Oblique', 'Courier-BoldOblique']
    }[fam];
    return table[(bold ? 1 : 0) + (italic ? 2 : 0)];
  }

  // Texto en WinAnsi: caracteres fuera de Latin-1 se sustituyen por "?"
  function pdfText(s) {
    return String(s).replace(/[\\()]/g, (c) => '\\' + c).replace(/[^\x00-\xff]/g, '?').replace(/\r?\n/g, ' ');
  }

  // Un elemento necesita rasterizarse en el PDF si usa efectos que el PDF no describe como vector
  function needsRaster(el) {
    if (el.type === 'asset') return true;
    if (el.type === 'image') return !!((el.mask && el.mask !== 'none') || el.shadow || el.fx || el.fy || hasFilt(el.filt));
    if (el.type === 'text') return !!(el.grad || el.hl || el.stroke || el.shadow || el.fx || el.fy);
    if (el.type === 'line') return !!(el.shadow || el.fx || el.fy);
    return !!(el.grad || el.stroke || el.shadow || el.fx || el.fy);
  }

  // Compresión zlib (FlateDecode) cuando el navegador lo permite; si no, se guarda sin comprimir
  async function deflate(bytes) {
    if (typeof CompressionStream === 'undefined') return { data: bytes, flate: false };
    const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream('deflate'));
    return { data: new Uint8Array(await new Response(stream).arrayBuffer()), flate: true };
  }

  // Dibuja el elemento sin rotar en un lienzo con transparencia; el PDF lo gira después
  async function rasterize(el) {
    const m = el.shadow ? Math.ceil(el.shadow.b + Math.max(Math.abs(el.shadow.x), Math.abs(el.shadow.y)) + 4) : 0;
    const scale = 3;
    const W = Math.ceil((el.w + 2 * m) * scale), H = Math.ceil((el.h + 2 * m) * scale);
    const cv = document.createElement('canvas');
    cv.width = W;
    cv.height = H;
    const ctx = cv.getContext('2d');
    ctx.scale(scale, scale);
    ctx.translate(m - el.x, m - el.y);
    await drawEl(ctx, Object.assign({}, el, { rot: 0, op: 1 }));
    const px = ctx.getImageData(0, 0, W, H).data;
    const rgb = new Uint8Array(W * H * 3), alpha = new Uint8Array(W * H);
    for (let i = 0, j = 0, k = 0; i < px.length; i += 4, j += 3, k++) {
      rgb[j] = px[i]; rgb[j + 1] = px[i + 1]; rgb[j + 2] = px[i + 2]; alpha[k] = px[i + 3];
    }
    const [c, a] = await Promise.all([deflate(rgb), deflate(alpha)]);
    return { W, H, m, rgb: c, alpha: a };
  }

  F.exp.pdf = async () => {
    const c = S.canvas();
    const W = c.width * PT, H = c.height * PT;
    const X = (x) => (x * PT).toFixed(3);
    const Y = (y) => ((c.height - y) * PT).toFixed(3);
    const rgb = (hex) => {
      const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex || '#000000');
      if (!m) return '0 0 0';
      return [1, 2, 3].map((i) => (parseInt(m[i], 16) / 255).toFixed(3)).join(' ');
    };
    const fonts = new Map(), gstates = new Map(), images = [], shadings = [];
    const fontKey = (name) => { if (!fonts.has(name)) fonts.set(name, 'F' + (fonts.size + 1)); return fonts.get(name); };
    const gsKey = (op) => {
      if (op >= 1) return null;
      const k = Math.round(op * 100) / 100;
      if (!gstates.has(k)) gstates.set(k, 'GS' + (gstates.size + 1));
      return gstates.get(k);
    };

    let ops = c.background === 'transparent' ? '' : `${rgb(c.background)} rg 0 0 ${W.toFixed(3)} ${H.toFixed(3)} re f\n`;

    for (const el of c.elements) {
      if (el.hidden) continue;
      const gs = gsKey(el.op == null ? 1 : el.op);
      const cx = el.x + el.w / 2, cy = el.y + el.h / 2;
      const pcx = cx * PT, pcy = (c.height - cy) * PT;
      const a = -(el.rot || 0) * Math.PI / 180;
      let block = 'q\n';
      if (gs) block += `/${gs} gs\n`;
      if (el.rot) {
        block += `1 0 0 1 ${pcx.toFixed(3)} ${pcy.toFixed(3)} cm\n`;
        block += `${Math.cos(a).toFixed(5)} ${Math.sin(a).toFixed(5)} ${(-Math.sin(a)).toFixed(5)} ${Math.cos(a).toFixed(5)} 0 0 cm\n`;
        block += `1 0 0 1 ${(-pcx).toFixed(3)} ${(-pcy).toFixed(3)} cm\n`;
      }
      if (needsRaster(el)) {
        // Elemento con efectos: se incrusta como imagen RGB con canal alfa (SMask)
        const r = await rasterize(el);
        const idx = 'Im' + (images.length + 1);
        images.push({ name: idx, kind: 'raw', w: r.W, h: r.H, rgb: r.rgb, alpha: r.alpha });
        const wpt = (el.w + 2 * r.m) * PT, hpt = (el.h + 2 * r.m) * PT;
        block += `${wpt.toFixed(3)} 0 0 ${hpt.toFixed(3)} ${X(el.x - r.m)} ${Y(el.y + el.h + r.m)} cm /${idx} Do\n`;
      } else if (el.type === 'rect' && el.radius) {
        const r = Math.min(el.radius, el.w / 2, el.h / 2) * PT;
        const x0 = el.x * PT, y0 = (c.height - el.y - el.h) * PT, x1 = x0 + el.w * PT, y1 = y0 + el.h * PT, k = K * r;
        block += `${rgb(el.fill)} rg\n`;
        block += `${(x0 + r).toFixed(3)} ${y0.toFixed(3)} m ${(x1 - r).toFixed(3)} ${y0.toFixed(3)} l `;
        block += `${(x1 - r + k).toFixed(3)} ${y0.toFixed(3)} ${x1.toFixed(3)} ${(y0 + r - k).toFixed(3)} ${x1.toFixed(3)} ${(y0 + r).toFixed(3)} c `;
        block += `${x1.toFixed(3)} ${(y1 - r).toFixed(3)} l `;
        block += `${x1.toFixed(3)} ${(y1 - r + k).toFixed(3)} ${(x1 - r + k).toFixed(3)} ${y1.toFixed(3)} ${(x1 - r).toFixed(3)} ${y1.toFixed(3)} c `;
        block += `${(x0 + r).toFixed(3)} ${y1.toFixed(3)} l `;
        block += `${(x0 + r - k).toFixed(3)} ${y1.toFixed(3)} ${x0.toFixed(3)} ${(y1 - r + k).toFixed(3)} ${x0.toFixed(3)} ${(y1 - r).toFixed(3)} c `;
        block += `${x0.toFixed(3)} ${(y0 + r).toFixed(3)} l `;
        block += `${x0.toFixed(3)} ${(y0 + r - k).toFixed(3)} ${(x0 + r - k).toFixed(3)} ${y0.toFixed(3)} ${(x0 + r).toFixed(3)} ${y0.toFixed(3)} c h f\n`;
      } else if (el.type === 'rect') {
        block += `${rgb(el.fill)} rg ${X(el.x)} ${Y(el.y + el.h)} ${(el.w * PT).toFixed(3)} ${(el.h * PT).toFixed(3)} re f\n`;
      } else if (el.type === 'poly' || el.type === 'triangle') {
        const pts = el.type === 'poly' ? elPoly(el) : [[el.x + el.w / 2, el.y], [el.x + el.w, el.y + el.h], [el.x, el.y + el.h]];
        block += `${rgb(el.fill)} rg `;
        pts.forEach((p, i) => { block += `${X(p[0])} ${Y(p[1])} ${i ? 'l' : 'm'} `; });
        block += 'h f\n';
      } else if (el.type === 'line') {
        const head = Math.max(12, el.h * 3), arrow = el.arrow || 'none';
        const x0 = el.x + (arrow === 'start' || arrow === 'both' ? head * 0.8 : 0);
        const x1 = el.x + el.w - (arrow === 'end' || arrow === 'both' ? head * 0.8 : 0);
        const yc = el.y + el.h / 2;
        const dash = el.dash === 'dashed' ? `[${(el.h * 3 * PT).toFixed(3)} ${(el.h * 2 * PT).toFixed(3)}] 0 d`
          : el.dash === 'dotted' ? `[${(el.h * PT).toFixed(3)} ${(el.h * 2 * PT).toFixed(3)}] 0 d` : '[] 0 d';
        block += `${rgb(el.fill)} RG ${(el.h * PT).toFixed(3)} w ${dash}\n`;
        block += `${X(x0)} ${Y(yc)} m ${X(x1)} ${Y(yc)} l S\n`;
        const tri = (bx, tx) => {
          block += `${rgb(el.fill)} rg ${X(bx)} ${Y(yc - head / 2)} m ${X(tx)} ${Y(yc)} l ${X(bx)} ${Y(yc + head / 2)} l h f\n`;
        };
        if (arrow === 'end' || arrow === 'both') tri(el.x + el.w - head, el.x + el.w);
        if (arrow === 'start' || arrow === 'both') tri(el.x + head, el.x);
      } else if (el.type === 'ellipse') {
        const rx = (el.w / 2) * PT, ry = (el.h / 2) * PT, ex = pcx, ey = pcy, kx = K * rx, ky = K * ry;
        block += `${rgb(el.fill)} rg\n`;
        block += `${(ex + rx).toFixed(3)} ${ey.toFixed(3)} m `;
        block += `${(ex + rx).toFixed(3)} ${(ey + ky).toFixed(3)} ${(ex + kx).toFixed(3)} ${(ey + ry).toFixed(3)} ${ex.toFixed(3)} ${(ey + ry).toFixed(3)} c `;
        block += `${(ex - kx).toFixed(3)} ${(ey + ry).toFixed(3)} ${(ex - rx).toFixed(3)} ${(ey + ky).toFixed(3)} ${(ex - rx).toFixed(3)} ${ey.toFixed(3)} c `;
        block += `${(ex - rx).toFixed(3)} ${(ey - ky).toFixed(3)} ${(ex - kx).toFixed(3)} ${(ey - ry).toFixed(3)} ${ex.toFixed(3)} ${(ey - ry).toFixed(3)} c `;
        block += `${(ex + kx).toFixed(3)} ${(ey - ry).toFixed(3)} ${(ex + rx).toFixed(3)} ${(ey - ky).toFixed(3)} ${(ex + rx).toFixed(3)} ${ey.toFixed(3)} c h f\n`;
      } else if (el.type === 'text') {
        const font = fontKey(pdfFont(el));
        const lh = el.size * 1.2;
        const lines = wrap(el.text, el.w, fontStr(el));
        block += `${rgb(el.fill)} rg BT /${font} ${(el.size * PT).toFixed(3)} Tf\n`;
        lines.forEach((ln, i) => {
          const tw = measureCtx.measureText(ln).width;
          let x = el.x;
          if (el.align === 'center') x = el.x + (el.w - tw) / 2;
          if (el.align === 'right') x = el.x + el.w - tw;
          const yBase = el.y + i * lh + el.size * 0.9;
          block += `1 0 0 1 ${X(x)} ${Y(yBase)} Tm (${pdfText(ln)}) Tj\n`;
        });
        block += 'ET\n';
      } else if (el.type === 'image') {
        // Imagen sin efectos: JPEG recortado al tamaño del marco
        const img = await F.loadImage(el.src);
        const idx = 'Im' + (images.length + 1);
        const cv = document.createElement('canvas');
        cv.width = Math.round(el.w * 2); cv.height = Math.round(el.h * 2);
        drawCover(cv.getContext('2d'), img, 0, 0, cv.width, cv.height);
        const jpeg = await new Promise((res) => cv.toBlob(res, 'image/jpeg', 0.92));
        images.push({ name: idx, kind: 'jpeg', w: cv.width, h: cv.height, bytes: new Uint8Array(await jpeg.arrayBuffer()) });
        block += `${(el.w * PT).toFixed(3)} 0 0 ${(el.h * PT).toFixed(3)} ${X(el.x)} ${Y(el.y + el.h)} cm /${idx} Do\n`;
      }
      if (el.type === 'ellipse' || el.type === 'rect' || el.type === 'line' || el.type === 'poly' || el.type === 'triangle' || el.type === 'text') {
        // el contenido vectorial ya quedó dibujado arriba
      }
      if (el.op && el.op !== 1 && !gs) block += '';
      block += 'Q\n';
      ops += block;
    }

    return buildPdf({ W, H, ops, fonts, gstates, images });
  };

  function buildPdf({ W, H, ops, fonts, gstates, images }) {
    const objs = [];
    const add = (...parts) => { objs.push(parts); return objs.length; };

    add('<< /Type /Catalog /Pages 2 0 R >>');
    add('<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
    const pageIdx = add('');
    const contentIdx = add('');
    const fontRefs = {};
    fonts.forEach((name, base) => {
      fontRefs[name] = add(`<< /Type /Font /Subtype /Type1 /BaseFont /${base} /Encoding /WinAnsiEncoding >>`);
    });
    const gsRefs = {};
    gstates.forEach((name, val) => {
      gsRefs[name] = add(`<< /Type /ExtGState /ca ${Number(val)} /CA ${Number(val)} >>`);
    });
    const imgRefs = {};
    images.forEach((im) => {
      if (im.kind === 'raw') {
        const fl = im.rgb.flate ? '/Filter /FlateDecode ' : '';
        const aflt = im.alpha.flate ? '/Filter /FlateDecode ' : '';
        const smask = add(`<< /Type /XObject /Subtype /Image /Width ${im.w} /Height ${im.h} /ColorSpace /DeviceGray /BitsPerComponent 8 ${aflt}/Length ${im.alpha.data.length} >>\nstream\n`, im.alpha.data, '\nendstream');
        imgRefs[im.name] = add(`<< /Type /XObject /Subtype /Image /Width ${im.w} /Height ${im.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 ${fl}/SMask ${smask} 0 R /Length ${im.rgb.data.length} >>\nstream\n`, im.rgb.data, '\nendstream');
      } else {
        imgRefs[im.name] = add(`<< /Type /XObject /Subtype /Image /Width ${im.w} /Height ${im.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${im.bytes.length} >>\nstream\n`, im.bytes, '\nendstream');
      }
    });

    const fontDict = Object.keys(fontRefs).map((n) => `/${n} ${fontRefs[n]} 0 R`).join(' ');
    const gsDict = Object.keys(gsRefs).map((n) => `/${n} ${gsRefs[n]} 0 R`).join(' ');
    const xDict = Object.keys(imgRefs).map((n) => `/${n} ${imgRefs[n]} 0 R`).join(' ');
    objs[pageIdx - 1] = [`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W.toFixed(3)} ${H.toFixed(3)}] /Contents 4 0 R /Resources << /Font << ${fontDict} >> /ExtGState << ${gsDict} >> /XObject << ${xDict} >> >> >>`];
    const contentBytes = enc(ops);
    objs[contentIdx - 1] = [`<< /Length ${contentBytes.length} >>\nstream\n`, contentBytes, '\nendstream'];

    const chunks = [];
    let pos = 0;
    const push = (x) => { const b = typeof x === 'string' ? enc(x) : x; chunks.push(b); pos += b.length; };
    push(enc('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n'));
    const offsets = [];
    objs.forEach((parts, i) => {
      offsets.push(pos);
      push(`${i + 1} 0 obj\n`);
      parts.forEach(push);
      push('\nendobj\n');
    });
    const xref = pos;
    let x = `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
    offsets.forEach((o) => { x += String(o).padStart(10, '0') + ' 00000 n \n'; });
    x += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
    push(x);
    return new Blob(chunks, { type: 'application/pdf' });
  }

  // ----- Word (.docx) desde el modo documento -----
  function docxRuns(node, flags, out) {
    node.childNodes.forEach((n) => {
      if (n.nodeType === 3) {
        if (n.textContent) out.push({ text: n.textContent, b: flags.b, i: flags.i, u: flags.u });
        return;
      }
      if (n.nodeType !== 1) return;
      const t = n.tagName;
      const f = { b: flags.b || t === 'B' || t === 'STRONG', i: flags.i || t === 'I' || t === 'EM', u: flags.u || t === 'U' };
      if (t === 'BR') { out.push({ text: '\n', b: f.b, i: f.i, u: f.u }); return; }
      docxRuns(n, f, out);
    });
    return out;
  }

  function docxBlocks(html) {
    const root = document.createElement('div');
    root.innerHTML = html;
    const blocks = [];
    const walk = (node) => {
      node.childNodes.forEach((n) => {
        if (n.nodeType === 3) {
          if (n.textContent.trim()) blocks.push({ style: null, runs: [{ text: n.textContent.trim() }] });
          return;
        }
        if (n.nodeType !== 1) return;
        const t = n.tagName;
        if (/^H[1-6]$/.test(t)) { blocks.push({ style: t === 'H1' ? 'Heading1' : 'Heading2', runs: docxRuns(n, {}, []) }); return; }
        if (t === 'LI') { const runs = docxRuns(n, {}, []); runs.unshift({ text: '• ' }); blocks.push({ style: null, runs }); return; }
        if (t === 'P' || t === 'DIV') { const runs = docxRuns(n, {}, []); if (runs.some((r) => r.text.trim())) blocks.push({ style: null, runs }); return; }
        walk(n);
      });
    };
    walk(root);
    return blocks;
  }

  function docxXml(blocks) {
    const esc = F.esc;
    const paras = blocks.map((b) => {
      const ppr = b.style ? `<w:pPr><w:pStyle w:val="${b.style}"/></w:pPr>` : '';
      const runs = b.runs.map((r) => {
        const rpr = (r.b ? '<w:b/>' : '') + (r.i ? '<w:i/>' : '') + (r.u ? '<w:u w:val="single"/>' : '');
        return `<w:r>${rpr ? `<w:rPr>${rpr}</w:rPr>` : ''}<w:t xml:space="preserve">${esc(r.text)}</w:t></w:r>`;
      }).join('');
      return `<w:p>${ppr}${runs}</w:p>`;
    }).join('');
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
      '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>' + paras +
      '<w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="720" w:footer="720" w:gutter="0"/></w:sectPr>' +
      '</w:body></w:document>';
  }

  F.exp.docx = () => {
    const html = F.document.html();
    const blocks = docxBlocks(html);
    if (!blocks.length) blocks.push({ style: null, runs: [{ text: ' ' }] });
    const W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
    const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="${W}">` +
      '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style>' +
      '<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>' +
      '<w:pPr><w:keepNext/><w:spacing w:before="240" w:after="120"/><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/><w:sz w:val="48"/></w:rPr></w:style>' +
      '<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>' +
      '<w:pPr><w:keepNext/><w:spacing w:before="200" w:after="100"/><w:outlineLvl w:val="1"/></w:pPr><w:rPr><w:b/><w:sz w:val="36"/></w:rPr></w:style>' +
      '</w:styles>';
    return F.zip([
      { name: '[Content_Types].xml', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>' },
      { name: '_rels/.rels', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>' },
      { name: 'word/_rels/document.xml.rels', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' },
      { name: 'word/document.xml', data: docxXml(blocks) },
      { name: 'word/styles.xml', data: styles }
    ], 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
  };

  F.exp.html = () => {
    const html = F.document.html();
    return `<!doctype html>\n<html lang="es"><head><meta charset="utf-8"><title>${F.esc(S.project().name)}</title>` +
      '<style>body{font-family:Inter,system-ui,sans-serif;max-width:760px;margin:40px auto;padding:0 20px;line-height:1.6;color:#0E1330}h1{font-size:32px}h2{font-size:22px}</style>' +
      `</head><body>${html}</body></html>`;
  };

  F.exp.txt = () => docxBlocks(F.document.html()).map((b) => b.runs.map((r) => r.text).join('')).join('\n\n');

  F.exp.json = () => JSON.stringify({ format: 'folium', version: 2, project: S.project() }, null, 2);

  // Descargas listas para el usuario
  F.exp.run = async (kind) => {
    const name = F.safeName(S.project().name);
    const map = {
      png: async () => F.download(await F.exp.png(2), name + '.png', 'image/png'),
      pdf: async () => F.download(await F.exp.pdf(), name + '.pdf', 'application/pdf'),
      svg: () => F.download(F.exp.svg(), name + '.svg', 'image/svg+xml'),
      docx: () => F.download(F.exp.docx(), name + '.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
      html: () => F.download(F.exp.html(), name + '.html', 'text/html'),
      txt: () => F.download(F.exp.txt(), name + '.txt', 'text/plain'),
      json: () => F.download(F.exp.json(), name + '.folium.json', 'application/json')
    };
    if (!map[kind]) return;
    try {
      await map[kind]();
      F.toast(`Archivo ${kind.toUpperCase()} exportado`, 'ok');
    } catch (err) {
      console.error(err);
      F.toast('No se pudo exportar: ' + (err.message || 'error'), 'error', 5000);
    }
  };
})();
