/* Folium · panel de efectos: degradado, sombra, contorno, resaltado, máscara y filtros de imagen, volteo y tipografía */
(function () {
  'use strict';
  const F = window.Folium, S = F.state, $ = F.$;

  const isShape = (s) => ['rect', 'ellipse', 'triangle', 'poly', 'asset', 'text'].includes(s.type);
  const isText = (s) => s.type === 'text';
  const isImg = (s) => s.type === 'image';
  const all = () => true;
  const clamp = F.clamp;

  // Aplica un cambio a los seleccionados que cumplen el filtro. commit=false solo refresca la vista (arrastre de controles)
  function apply(filter, fn, commit) {
    const list = S.selected().filter(filter);
    if (!list.length) return;
    list.forEach(fn);
    if (commit) S.commit(); else S.live();
  }

  // Un campo en uso no se reescribe mientras el usuario escribe
  function put(input, v) {
    if (!input || document.activeElement === input) return;
    if (input.type === 'checkbox') input.checked = !!v;
    else input.value = v;
  }

  const on = (id, ev, fn) => { const n = $('#' + id); if (n) n.addEventListener(ev, fn); };
  const num = (e) => Number(e.target.value);

  // ----- Degradado -----
  on('gOn', 'change', (e) => apply(isShape, (s) => {
    if (e.target.checked) s.grad = s.grad || { c1: s.fill && /^#/.test(s.fill) ? s.fill : '#2563FF', c2: '#7A3CFF', a: 135 };
    else s.grad = null;
  }, true));
  on('gPreset', 'change', (e) => {
    const g = F.GRADIENTS[e.target.value];
    if (!g) return;
    apply(isShape, (s) => { s.grad = { c1: g.c1, c2: g.c2, a: s.grad ? s.grad.a : 135 }; }, true);
  });
  ['gC1', 'gC2'].forEach((id) => {
    const key = id === 'gC1' ? 'c1' : 'c2';
    on(id, 'input', (e) => apply(isShape, (s) => { if (s.grad) s.grad[key] = e.target.value; }, false));
    on(id, 'change', (e) => apply(isShape, (s) => { if (s.grad) s.grad[key] = e.target.value; }, true));
  });
  on('gA', 'input', (e) => apply(isShape, (s) => { if (s.grad) s.grad.a = clamp(num(e), 0, 360); }, false));
  on('gA', 'change', (e) => apply(isShape, (s) => { if (s.grad) s.grad.a = clamp(num(e), 0, 360); }, true));

  // ----- Sombra -----
  on('sOn', 'change', (e) => apply(all, (s) => {
    s.shadow = e.target.checked ? (s.shadow || { c: '#000000', b: 12, x: 0, y: 6 }) : null;
  }, true));
  on('sC', 'input', (e) => apply((s) => !!s.shadow, (s) => { s.shadow.c = e.target.value; }, false));
  on('sC', 'change', (e) => apply((s) => !!s.shadow, (s) => { s.shadow.c = e.target.value; }, true));
  [['sB', 'b', 0, 80], ['sX', 'x', -60, 60], ['sY', 'y', -60, 60]].forEach(([id, key, lo, hi]) => {
    on(id, 'input', (e) => apply((s) => !!s.shadow, (s) => { s.shadow[key] = clamp(num(e), lo, hi); }, false));
    on(id, 'change', (e) => apply((s) => !!s.shadow, (s) => { s.shadow[key] = clamp(num(e), lo, hi); }, true));
  });

  // ----- Contorno -----
  on('kOn', 'change', (e) => apply(isShape, (s) => {
    s.stroke = e.target.checked ? (s.stroke || { c: '#0E1330', w: 4 }) : null;
  }, true));
  on('kC', 'input', (e) => apply((s) => !!s.stroke, (s) => { s.stroke.c = e.target.value; }, false));
  on('kC', 'change', (e) => apply((s) => !!s.stroke, (s) => { s.stroke.c = e.target.value; }, true));
  on('kW', 'input', (e) => apply((s) => !!s.stroke, (s) => { s.stroke.w = clamp(num(e), 0, 40); }, false));
  on('kW', 'change', (e) => apply((s) => !!s.stroke, (s) => { s.stroke.w = clamp(num(e), 0, 40); }, true));

  // ----- Resaltado de texto -----
  on('hOn', 'change', (e) => apply(isText, (s) => { s.hl = e.target.checked ? (s.hl || '#FFF3A3') : null; }, true));
  on('hC', 'input', (e) => apply((s) => isText(s) && !!s.hl, (s) => { s.hl = e.target.value; }, false));
  on('hC', 'change', (e) => apply((s) => isText(s) && !!s.hl, (s) => { s.hl = e.target.value; }, true));

  // ----- Imagen: máscara y filtros -----
  on('mSel', 'change', (e) => apply(isImg, (s) => { s.mask = e.target.value; }, true));
  const FILT = { iBr: ['br', 100, 0, 200], iCt: ['ct', 100, 0, 200], iSa: ['sa', 100, 0, 300], iBl: ['bl', 0, 0, 20], iGs: ['gs', 0, 0, 100], iSe: ['se', 0, 0, 100] };
  Object.keys(FILT).forEach((id) => {
    const [key, , lo, hi] = FILT[id];
    const set = (s, v) => {
      s.filt = s.filt || { br: 100, ct: 100, sa: 100, bl: 0, gs: 0, se: 0 };
      s.filt[key] = clamp(v, lo, hi);
    };
    on(id, 'input', (e) => apply(isImg, (s) => set(s, num(e)), false));
    on(id, 'change', (e) => apply(isImg, (s) => set(s, num(e)), true));
  });

  // ----- Volteo -----
  on('flipH', 'click', () => apply(all, (s) => { s.fx = !s.fx; }, true));
  on('flipV', 'click', () => apply(all, (s) => { s.fy = !s.fy; }, true));

  // ----- Tipografía: lista de familias del modelo -----
  function fillFonts(select) {
    if (!select || select.options.length) return;
    (F.FONT_OPTIONS || Object.keys(F.FONTS)).forEach((k) => {
      const o = document.createElement('option');
      o.value = k;
      o.textContent = F.FONTS[k].label;
      o.style.fontFamily = F.FONTS[k].css;
      select.appendChild(o);
    });
  }

  function fillMasks() {
    const sel = $('#mSel');
    if (!sel || sel.options.length) return;
    const base = [['none', 'Sin máscara'], ['ellipse', 'Círculo'], ['rounded', 'Esquinas redondeadas']];
    base.forEach(([v, l]) => { const o = document.createElement('option'); o.value = v; o.textContent = l; sel.appendChild(o); });
    Object.keys(F.SHAPES).forEach((k) => { const o = document.createElement('option'); o.value = k; o.textContent = F.SHAPES[k]; sel.appendChild(o); });
  }

  // ----- Vista: muestra los controles que aplican a la selección -----
  function update() {
    const group = $('#fxGroup');
    if (!group) return;
    const list = S.selected();
    group.hidden = !list.length;
    if (!list.length) return;
    const any = (f) => list.some(f);
    $('#gradRow').hidden = !any(isShape);
    $('#strokeRow').hidden = !any(isShape);
    $('#hlRow').hidden = !any(isText);
    $('#imgRow').hidden = !any(isImg);
    $('#shadowRow').hidden = false;
    $('#flipRow').hidden = false;

    const s = list[0];
    put($('#gOn'), !!s.grad);
    if (s.grad) { put($('#gC1'), s.grad.c1); put($('#gC2'), s.grad.c2); put($('#gA'), s.grad.a); }
    put($('#sOn'), !!s.shadow);
    if (s.shadow) { put($('#sC'), s.shadow.c); put($('#sB'), s.shadow.b); put($('#sX'), s.shadow.x); put($('#sY'), s.shadow.y); }
    put($('#kOn'), !!s.stroke);
    if (s.stroke) { put($('#kC'), s.stroke.c); put($('#kW'), s.stroke.w); }
    put($('#hOn'), !!s.hl);
    if (s.hl) put($('#hC'), s.hl);
    if (isImg(s)) {
      put($('#mSel'), s.mask || 'none');
      const f = s.filt || { br: 100, ct: 100, sa: 100, bl: 0, gs: 0, se: 0 };
      put($('#iBr'), f.br); put($('#iCt'), f.ct); put($('#iSa'), f.sa);
      put($('#iBl'), f.bl); put($('#iGs'), f.gs); put($('#iSe'), f.se);
    }
    const gp = $('#gPreset');
    if (gp && document.activeElement !== gp) gp.value = '';
  }

  // Resplandor: sombra sin desplazamiento, con el color del elemento
  on('glowBtn', 'click', () => apply(all, (s) => {
    s.shadow = { c: s.fill && /^#/.test(s.fill) ? s.fill : '#FFB020', b: 28, x: 0, y: 0 };
  }, true));

  fillFonts($('#fFont'));
  fillMasks();
  ['selection', 'change', 'history', 'project', 'live'].forEach((ev) => F.on(ev, update));
  F.effectsPanel = { update };
})();
