/* Folium · render del lienzo: elementos con efectos (degradado, sombra, contorno, resaltado, máscara,
   filtros y volteo), assets, marco de selección, manejadores, guías, selección por arrastre y lienzo vacío */
(function () {
  'use strict';
  const F = window.Folium, S = F.state, $ = F.$;
  const artboard = $('#artboard');
  const sizer = $('#sizer');
  const zoomLabel = $('#zoomLabel');
  const zoomOut = $('#zoomOut');
  const zoomIn = $('#zoomIn');
  const SVG_NS = 'http://www.w3.org/2000/svg';

  F.ZOOMS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2];
  let zi = 1;
  const nodes = new Map();

  // Estado visual que mantiene interact.js
  F.guides = [];
  F.marquee = null;

  const overlay = document.createElement('div');
  overlay.className = 'overlay';
  overlay.setAttribute('aria-hidden', 'true');
  artboard.appendChild(overlay);

  F.zoom = () => F.ZOOMS[zi];
  F.zoomIndex = () => zi;
  F.zoomIndexFor = (percent) => {
    const t = Number(percent) / 100;
    let best = 0;
    F.ZOOMS.forEach((z, i) => { if (Math.abs(z - t) < Math.abs(F.ZOOMS[best] - t)) best = i; });
    return best;
  };
  F.setZoom = (i) => {
    zi = F.clamp(i, 0, F.ZOOMS.length - 1);
    F.render.canvas();
  };
  F.zoomToFit = () => {
    const c = S.canvas();
    const stage = $('#stageScroll');
    const fit = Math.min((stage.clientWidth - 80) / c.width, (stage.clientHeight - 80) / c.height);
    let best = 0;
    F.ZOOMS.forEach((z, i) => { if (z <= fit) best = i; });
    F.setZoom(best);
  };

  // ----- Utilidades de estilo -----
  const gradCss = (g) => `linear-gradient(${g.a}deg, ${g.c1}, ${g.c2})`;

  function maskCss(el) {
    const m = el.mask;
    if (!m || m === 'none') return '';
    if (m === 'ellipse') return 'ellipse(50% 50% at 50% 50%)';
    if (m === 'rounded') return `inset(0 round ${Math.round(Math.min(el.w, el.h) * 0.18)}px)`;
    return 'polygon(' + F.shapePoints(m).map((p) => p[0].toFixed(2) + '% ' + p[1].toFixed(2) + '%').join(', ') + ')';
  }

  function filterCss(el) {
    const parts = [];
    const f = el.filt;
    if (el.type === 'image' && f) {
      if (f.br !== 100) parts.push(`brightness(${f.br}%)`);
      if (f.ct !== 100) parts.push(`contrast(${f.ct}%)`);
      if (f.sa !== 100) parts.push(`saturate(${f.sa}%)`);
      if (f.bl) parts.push(`blur(${f.bl}px)`);
      if (f.gs) parts.push(`grayscale(${f.gs}%)`);
      if (f.se) parts.push(`sepia(${f.se}%)`);
    }
    if (el.shadow) parts.push(`drop-shadow(${el.shadow.x}px ${el.shadow.y}px ${el.shadow.b}px ${el.shadow.c})`);
    return parts.join(' ');
  }

  function transformCss(el) {
    const parts = [];
    if (el.rot) parts.push(`rotate(${el.rot}deg)`);
    if (el.fx || el.fy) parts.push(`scale(${el.fx ? -1 : 1}, ${el.fy ? -1 : 1})`);
    return parts.join(' ');
  }

  function svgEl(tag, attrs) {
    const el = document.createElementNS(SVG_NS, tag);
    Object.keys(attrs || {}).forEach((k) => el.setAttribute(k, attrs[k]));
    return el;
  }

  // Degradado dentro de un SVG (coordenadas relativas a la caja del elemento)
  function syncSvgGrad(root, el) {
    let defs = root.querySelector('defs');
    if (!el.grad) {
      if (defs) defs.remove();
      return null;
    }
    if (!defs) {
      defs = svgEl('defs');
      root.insertBefore(defs, root.firstChild);
    }
    let g = defs.querySelector('linearGradient');
    if (!g) {
      g = svgEl('linearGradient', { id: 'g-' + el.id });
      defs.appendChild(g);
    }
    const r = (el.grad.a * Math.PI) / 180, dx = Math.sin(r), dy = -Math.cos(r);
    g.setAttribute('x1', (0.5 - dx / 2).toFixed(3));
    g.setAttribute('y1', (0.5 - dy / 2).toFixed(3));
    g.setAttribute('x2', (0.5 + dx / 2).toFixed(3));
    g.setAttribute('y2', (0.5 + dy / 2).toFixed(3));
    g.innerHTML = '';
    g.appendChild(svgEl('stop', { offset: '0', 'stop-color': el.grad.c1 }));
    g.appendChild(svgEl('stop', { offset: '1', 'stop-color': el.grad.c2 }));
    return 'url(#g-' + el.id + ')';
  }

  // Aplica contorno a un trazo SVG (la anchura no se escala con la caja)
  function strokeSvg(node, el) {
    if (el.stroke) {
      node.setAttribute('stroke', el.stroke.c);
      node.setAttribute('stroke-width', el.stroke.w);
      node.setAttribute('vector-effect', 'non-scaling-stroke');
      node.setAttribute('stroke-linejoin', 'round');
    } else {
      node.removeAttribute('stroke');
      node.removeAttribute('stroke-width');
      node.removeAttribute('vector-effect');
    }
  }

  function polyPoints(pts) {
    return pts.map((p) => p[0].toFixed(2) + ',' + p[1].toFixed(2)).join(' ');
  }

  // Hijos según el tipo; se reconstruyen solo cuando cambia el tipo o la forma
  function buildChildren(n, el) {
    n.innerHTML = '';
    if (el.type === 'triangle') {
      const s = svgEl('svg', { viewBox: '0 0 100 100', preserveAspectRatio: 'none', 'aria-hidden': 'true' });
      s.appendChild(svgEl('polygon', { points: '50,0 100,100 0,100' }));
      n.appendChild(s);
    }
    if (el.type === 'poly') {
      const s = svgEl('svg', { viewBox: '0 0 100 100', preserveAspectRatio: 'none', 'aria-hidden': 'true' });
      s.appendChild(svgEl('polygon', { points: polyPoints(F.shapePoints(el.shape)) }));
      n.appendChild(s);
    }
    if (el.type === 'asset') {
      const a = F.ASSET_BY_ID[el.aid] || F.ASSETS[0];
      const s = svgEl('svg', { viewBox: a.vb, preserveAspectRatio: 'none', 'aria-hidden': 'true' });
      a.paths.forEach((d) => {
        const p = svgEl('path', { d });
        if (a.rule) p.setAttribute('fill-rule', a.rule);
        s.appendChild(p);
      });
      n.appendChild(s);
    }
    if (el.type === 'text') {
      const span = document.createElement('span');
      span.className = 't';
      n.appendChild(span);
    }
    if (el.type === 'image') {
      const img = document.createElement('img');
      img.alt = '';
      n.appendChild(img);
    }
  }

  // Línea: borde superior con el grosor del elemento, trazo y flechas
  function paintLine(n, el) {
    n.style.background = 'transparent';
    n.style.borderRadius = '0';
    const style = el.dash === 'dashed' || el.dash === 'dotted' ? el.dash : 'solid';
    n.style.borderTop = `${el.h}px ${style} ${el.fill}`;
    n.querySelectorAll('.arrow').forEach((a) => a.remove());
    const head = Math.max(12, el.h * 3);
    const arrow = el.arrow || 'none';
    const mk = (side) => {
      const s = svgEl('svg', { class: 'arrow arrow-' + side, viewBox: '0 0 10 10', preserveAspectRatio: 'none', 'aria-hidden': 'true' });
      s.style.width = head + 'px';
      s.style.height = head + 'px';
      s.appendChild(svgEl('polygon', { points: side === 'end' ? '0,0 10,5 0,10' : '10,0 0,5 10,10', fill: el.fill }));
      n.appendChild(s);
    };
    if (arrow === 'end' || arrow === 'both') mk('end');
    if (arrow === 'start' || arrow === 'both') mk('start');
  }

  function paintEl(n, el) {
    const editing = n.classList.contains('is-editing');
    n.className = 'el el-' + el.type + (el.locked ? ' locked' : '') + (el.hidden ? ' hidden-el' : '') + (editing ? ' is-editing' : '');
    n.dataset.id = el.id;
    n.style.left = el.x + 'px';
    n.style.top = el.y + 'px';
    n.style.width = el.w + 'px';
    n.style.height = el.h + 'px';
    n.style.opacity = el.op == null ? 1 : el.op;
    n.style.transform = transformCss(el);
    n.style.filter = filterCss(el);
    n.style.clipPath = el.type === 'image' ? maskCss(el) : '';

    const key = el.type + (el.type === 'poly' ? ':' + el.shape : '') + (el.type === 'asset' ? ':' + el.aid : '');
    if (n.dataset.kind !== key) {
      n.dataset.kind = key;
      buildChildren(n, el);
    }

    // Reinicia los estilos que dependen del elemento antes de aplicarlos
    n.style.background = '';
    n.style.borderRadius = '';
    n.style.border = '';
    n.style.borderTop = '';

    switch (el.type) {
      case 'rect':
        n.style.background = el.grad ? gradCss(el.grad) : el.fill;
        n.style.borderRadius = (el.radius || 0) + 'px';
        if (el.stroke) n.style.border = `${el.stroke.w}px solid ${el.stroke.c}`;
        break;
      case 'ellipse':
        n.style.background = el.grad ? gradCss(el.grad) : el.fill;
        if (el.stroke) n.style.border = `${el.stroke.w}px solid ${el.stroke.c}`;
        break;
      case 'triangle':
      case 'poly': {
        const svg = n.querySelector('svg');
        const poly = svg.querySelector('polygon');
        poly.setAttribute('fill', syncSvgGrad(svg, el) || el.fill);
        strokeSvg(poly, el);
        break;
      }
      case 'asset': {
        const svg = n.querySelector('svg');
        const fill = syncSvgGrad(svg, el) || el.fill;
        svg.querySelectorAll('path').forEach((p) => { p.setAttribute('fill', fill); strokeSvg(p, el); });
        break;
      }
      case 'line':
        paintLine(n, el);
        break;
      case 'text': {
        const span = n.querySelector('.t');
        const f = F.fontOf(el.font);
        n.style.fontFamily = f.css;
        span.style.fontFamily = f.css;
        span.style.color = el.grad ? 'transparent' : el.fill;
        span.style.webkitTextFillColor = el.grad ? 'transparent' : '';
        span.style.background = el.grad ? gradCss(el.grad) : (el.hl || '');
        span.style.webkitBackgroundClip = el.grad ? 'text' : '';
        span.style.backgroundClip = el.grad ? 'text' : '';
        span.style.webkitTextStroke = el.stroke ? `${el.stroke.w}px ${el.stroke.c}` : '';
        span.style.fontSize = el.size + 'px';
        span.style.fontWeight = el.weight;
        span.style.fontStyle = el.italic ? 'italic' : 'normal';
        span.style.textAlign = el.align || 'left';
        if (!editing && span.textContent !== el.text) span.textContent = el.text;
        break;
      }
      case 'image': {
        const img = n.querySelector('img');
        if (img.getAttribute('src') !== el.src) img.src = el.src;
        break;
      }
    }
  }

  function renderOverlay() {
    overlay.innerHTML = '';
    const sel = S.selected().filter((e) => !e.hidden);
    const c = S.canvas();

    if (!c.elements.length) {
      const hint = document.createElement('div');
      hint.className = 'empty-hint';
      hint.style.left = c.width / 2 + 'px';
      hint.style.top = c.height / 2 + 'px';
      hint.innerHTML = '<strong>Lienzo vacío</strong><span>Agrega formas, texto o elementos desde la pestaña Elementos, o elige una plantilla en Inicio.</span>';
      overlay.appendChild(hint);
    }

    if (sel.length === 1) {
      const el = sel[0];
      const frame = document.createElement('div');
      frame.className = 'sel-frame';
      Object.assign(frame.style, { left: el.x + 'px', top: el.y + 'px', width: el.w + 'px', height: el.h + 'px', transform: el.rot ? `rotate(${el.rot}deg)` : '' });
      overlay.appendChild(frame);
      if (!el.locked) {
        const cx = el.x + el.w / 2, cy = el.y + el.h / 2;
        const a = ((el.rot || 0) * Math.PI) / 180;
        const dx = el.w / 2, dy = el.h / 2;
        const h = document.createElement('div');
        h.className = 'handle';
        h.dataset.h = 'se';
        Object.assign(h.style, {
          left: cx + dx * Math.cos(a) - dy * Math.sin(a) + 'px',
          top: cy + dx * Math.sin(a) + dy * Math.cos(a) + 'px',
          right: 'auto', bottom: 'auto', transform: 'translate(-50%, -50%)'
        });
        overlay.appendChild(h);
      }
      if (!el.locked) {
        // Tirador de giro: por encima del borde superior, siguiendo la rotación del elemento
        const cx = el.x + el.w / 2, cy = el.y + el.h / 2;
        const a = ((el.rot || 0) * Math.PI) / 180;
        const d = el.h / 2 + 30;
        const rh = document.createElement('div');
        rh.className = 'rot-handle';
        rh.dataset.h = 'rot';
        rh.title = 'Girar (Mayús: pasos de 15°)';
        Object.assign(rh.style, { left: cx + d * Math.sin(a) + 'px', top: cy - d * Math.cos(a) + 'px' });
        overlay.appendChild(rh);
      }
    } else if (sel.length > 1) {
      const b = F.unionBox(sel);
      const frame = document.createElement('div');
      frame.className = 'sel-frame multi';
      Object.assign(frame.style, { left: b.x + 'px', top: b.y + 'px', width: b.w + 'px', height: b.h + 'px' });
      overlay.appendChild(frame);
    }

    F.guides.forEach((g) => {
      const d = document.createElement('div');
      d.className = 'guide ' + g.axis;
      if (g.axis === 'v') d.style.left = g.pos + 'px'; else d.style.top = g.pos + 'px';
      overlay.appendChild(d);
    });

    if (F.marquee) {
      const m = F.marquee, d = document.createElement('div');
      d.className = 'marquee';
      Object.assign(d.style, { left: m.x + 'px', top: m.y + 'px', width: m.w + 'px', height: m.h + 'px' });
      overlay.appendChild(d);
    }
    return c;
  }

  F.render = {
    canvas() {
      const c = S.canvas();
      const z = F.zoom();
      artboard.style.width = c.width + 'px';
      artboard.style.height = c.height + 'px';
      artboard.style.backgroundColor = c.background === 'transparent' ? '' : c.background;
      artboard.classList.toggle('transparent-bg', c.background === 'transparent');
      artboard.style.transform = `scale(${z})`;
      sizer.style.width = c.width * z + 'px';
      sizer.style.height = c.height * z + 'px';
      zoomLabel.textContent = Math.round(z * 100) + '%';
      zoomOut.disabled = zi === 0;
      zoomIn.disabled = zi === F.ZOOMS.length - 1;
      artboard.classList.toggle('show-grid', !!F.settings.get('showGrid'));

      const seen = new Set();
      c.elements.forEach((el) => {
        let n = nodes.get(el.id);
        if (!n) {
          n = document.createElement('div');
          nodes.set(el.id, n);
        }
        seen.add(el.id);
        paintEl(n, el);
        artboard.insertBefore(n, overlay);
      });
      [...nodes.keys()].forEach((id) => {
        if (!seen.has(id)) { nodes.get(id).remove(); nodes.delete(id); }
      });
      renderOverlay();
    },

    overlay: renderOverlay,

    element(el) {
      const n = nodes.get(el.id);
      if (n) paintEl(n, el);
    },

    nodeOf: (id) => nodes.get(id),

    forget(id) { nodes.delete(id); }
  };

  F.on('change', () => F.render.canvas());
  F.on('live', () => F.render.canvas());
  F.on('selection', () => renderOverlay());
  F.on('settings', () => F.render.canvas());
  F.on('project', () => { nodes.forEach((n) => n.remove()); nodes.clear(); F.render.canvas(); });
  F.on('history', () => F.render.canvas());
})();
