/* Folium · acciones de edición del lienzo: agregar, duplicar, copiar, borrar, ordenar, alinear y mover */
(function () {
  'use strict';
  const F = window.Folium, S = F.state;

  F.actions = {};
  const A = F.actions;

  A.add = (type, props) => {
    const c = S.canvas();
    const el = F.makeElement(type, props);
    const offset = (S.els().length % 6) * 18;
    el.x = Math.round((c.width - el.w) / 2 + offset);
    el.y = Math.round((c.height - el.h) / 2 + offset);
    S.els().push(el);
    S.setSelection([el.id]);
    S.commit();
    return el;
  };

  A.duplicate = () => {
    const sel = S.selected();
    if (!sel.length) return;
    const ids = [];
    sel.forEach((src) => {
      const copy = { ...JSON.parse(JSON.stringify(src)), id: F.uid('e'), x: src.x + 24, y: src.y + 24 };
      S.els().push(copy);
      ids.push(copy.id);
    });
    S.setSelection(ids);
    S.commit();
  };

  A.remove = () => {
    const ids = S.selection.slice();
    if (!ids.length) return;
    S.canvas().elements = S.els().filter((e) => !ids.includes(e.id));
    S.setSelection([]);
    S.commit();
  };

  A.copy = () => {
    const sel = S.selected();
    if (sel.length) S.clipboard = JSON.parse(JSON.stringify(sel));
    if (sel.length) F.toast(sel.length === 1 ? 'Elemento copiado' : sel.length + ' elementos copiados', '', 1400);
  };

  A.paste = () => {
    if (!S.clipboard || !S.clipboard.length) return;
    const ids = [];
    S.clipboard.forEach((src) => {
      const copy = { ...JSON.parse(JSON.stringify(src)), id: F.uid('e'), x: src.x + 24, y: src.y + 24 };
      S.clipboard_last = copy;
      S.els().push(copy);
      ids.push(copy.id);
    });
    S.clipboard.forEach((src) => { src.x += 24; src.y += 24; });
    S.setSelection(ids);
    S.commit();
  };

  A.nudge = (dx, dy) => {
    const sel = S.selected().filter((e) => !e.locked);
    if (!sel.length) return;
    sel.forEach((e) => { e.x += dx; e.y += dy; });
    S.commit();
  };

  // Orden de capas: el arreglo de elementos va de atrás hacia adelante
  A.zorder = (kind) => {
    const els = S.els();
    const sel = S.selected();
    if (!sel.length) return;
    const ids = sel.map((e) => e.id);
    const picked = els.filter((e) => ids.includes(e.id));
    const rest = els.filter((e) => !ids.includes(e.id));
    if (kind === 'front') els.splice(0, els.length, ...rest, ...picked);
    else if (kind === 'back') els.splice(0, els.length, ...picked, ...rest);
    else if (kind === 'up' || kind === 'down') {
      const sorted = els.slice();
      const order = kind === 'up' ? sorted.map((e, i) => i).reverse() : sorted.map((e, i) => i);
      for (const i of order) {
        const e = sorted[i];
        if (!ids.includes(e.id)) continue;
        const j = kind === 'up' ? i + 1 : i - 1;
        if (j < 0 || j >= sorted.length) continue;
        if (ids.includes(sorted[j].id)) continue;
        [sorted[i], sorted[j]] = [sorted[j], sorted[i]];
      }
      els.splice(0, els.length, ...sorted);
    }
    S.commit();
  };

  // Alineación y distribución respecto al conjunto seleccionado
  A.align = (kind) => {
    const sel = S.selected().filter((e) => !e.locked);
    if (sel.length < 2) return;
    const b = F.unionBox(sel);
    if (kind === 'left') sel.forEach((e) => { e.x = b.x; });
    if (kind === 'hcenter') sel.forEach((e) => { e.x = b.x + (b.w - e.w) / 2; });
    if (kind === 'right') sel.forEach((e) => { e.x = b.x + b.w - e.w; });
    if (kind === 'top') sel.forEach((e) => { e.y = b.y; });
    if (kind === 'vcenter') sel.forEach((e) => { e.y = b.y + (b.h - e.h) / 2; });
    if (kind === 'bottom') sel.forEach((e) => { e.y = b.y + b.h - e.h; });
    if (kind === 'dh' && sel.length >= 3) distribute(sel, 'x', 'w');
    if (kind === 'dv' && sel.length >= 3) distribute(sel, 'y', 'h');
    S.commit();
  };

  function distribute(sel, pos, size) {
    const items = sel.slice().sort((a, b) => a[pos] - b[pos]);
    const first = items[0][pos];
    const last = items[items.length - 1];
    const span = last[pos] + last[size] - first;
    const total = items.reduce((s, e) => s + e[size], 0);
    const gap = (span - total) / (items.length - 1);
    let cur = first;
    items.forEach((e) => { e[pos] = Math.round(cur); cur += e[size] + gap; });
  }

  // Cambio de una propiedad en todos los seleccionados (con historial al final)
  A.setProp = (prop, value, commit) => {
    S.selected().forEach((e) => { e[prop] = value; });
    if (commit) S.commit(); else S.live();
  };

  // Mover la selección a una posición exacta (solo cuando hay un elemento)
  A.moveTo = (x, y) => {
    const el = S.selected()[0];
    if (!el) return;
    if (x != null) el.x = x;
    if (y != null) el.y = y;
  };

  A.toggleSelectedFlag = (flag) => {
    const sel = S.selected();
    if (!sel.length) return;
    const next = !sel[0][flag];
    sel.forEach((e) => { e[flag] = next; });
    S.commit();
  };

  // Elementos de la biblioteca (iconos, stickers, marcos)
  A.addAsset = (aid) => {
    const a = F.ASSET_BY_ID[aid];
    if (!a) return null;
    const big = a.cat === 'frame' ? 320 : 200;
    return A.add('asset', { aid, name: a.label, w: big, h: big, fill: '#2563FF' });
  };

  // Fondo con degradado: un rectángulo del tamaño del lienzo, al fondo de todo
  A.addBackground = (key) => {
    const g = F.GRADIENTS[key];
    const c = S.canvas();
    if (!g) return null;
    const el = F.makeElement('rect', {
      x: 0, y: 0, w: c.width, h: c.height, radius: 0, fill: g.c1,
      grad: { c1: g.c1, c2: g.c2, a: 135 }, name: 'Fondo ' + g.label
    });
    S.els().unshift(el);
    S.setSelection([el.id]);
    S.commit();
    return el;
  };
})();
