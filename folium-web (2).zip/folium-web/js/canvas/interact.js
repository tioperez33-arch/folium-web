/* Folium · interacción: selección (clic, Shift, recuadro), arrastre con guías inteligentes, redimensionado,
   edición de texto y atajos de teclado */
(function () {
  'use strict';
  const F = window.Folium, S = F.state, $ = F.$;
  const artboard = $('#artboard');
  const GRID = 20;
  const SNAP_PX = 6;
  let gesture = null;
  let lastTap = { id: null, t: 0 };

  // Punto en coordenadas del lienzo (independiente del zoom y del desplazamiento)
  function pt(e) {
    const r = artboard.getBoundingClientRect();
    const z = F.zoom();
    return { x: (e.clientX - r.left) / z, y: (e.clientY - r.top) / z };
  }

  function inputFocused(target) {
    return target && target.closest && target.closest('input, textarea, select, [contenteditable="true"]');
  }

  // Guías inteligentes: alinea bordes y centros del grupo con otros elementos y con el lienzo
  function smartSnap(box, exclude) {
    const c = S.canvas();
    const thr = SNAP_PX / F.zoom();
    const others = S.els().filter((e) => !e.hidden && !exclude.includes(e.id));
    const xs = [0, c.width / 2, c.width], ys = [0, c.height / 2, c.height];
    others.forEach((e) => { xs.push(e.x, e.x + e.w / 2, e.x + e.w); ys.push(e.y, e.y + e.h / 2, e.y + e.h); });
    const guides = [];
    const pickX = () => {
      let best = null;
      [box.x, box.x + box.w / 2, box.x + box.w].forEach((p, k) => {
        xs.forEach((t) => {
          const d = t - p;
          if (Math.abs(d) <= thr && (!best || Math.abs(d) < Math.abs(best.d))) best = { d, t, k };
        });
      });
      return best;
    };
    const pickY = () => {
      let best = null;
      [box.y, box.y + box.h / 2, box.y + box.h].forEach((p, k) => {
        ys.forEach((t) => {
          const d = t - p;
          if (Math.abs(d) <= thr && (!best || Math.abs(d) < Math.abs(best.d))) best = { d, t, k };
        });
      });
      return best;
    };
    const bx = pickX(), by = pickY();
    let dx = 0, dy = 0;
    if (bx) { dx = bx.d; guides.push({ axis: 'v', pos: bx.t }); }
    if (by) { dy = by.d; guides.push({ axis: 'h', pos: by.t }); }
    F.guides = guides;
    return { dx, dy };
  }

  function startMove(e, id) {
    const el = S.find(id);
    if (!el || el.hidden) return;
    if (e.shiftKey) {
      const ids = S.selection.includes(id) ? S.selection.filter((x) => x !== id) : [...S.selection, id];
      S.setSelection(ids);
    } else if (!S.selection.includes(id)) {
      S.setSelection([id]);
    }
    const movable = S.selected().filter((x) => !x.locked && !x.hidden);
    if (!movable.length) return;
    gesture = {
      type: 'move', start: pt(e), moved: false,
      origins: movable.map((x) => ({ id: x.id, x: x.x, y: x.y }))
    };
  }

  function startResize(e) {
    const el = S.selected()[0];
    if (!el || el.locked) return;
    gesture = { type: 'resize', start: pt(e), moved: false, id: el.id, ow: el.w, oh: el.h, rot: el.rot || 0 };
  }

  // Doble toque o doble clic en un texto: edición en el lienzo
  function startEdit(node, el) {
    if (node.classList.contains('is-editing')) return;
    gesture = null;
    lastTap = { id: null, t: 0 };
    node.classList.add('is-editing');
    node.contentEditable = 'true';
    node.focus();
    const span = node.querySelector('.t');
    const range = document.createRange();
    range.selectNodeContents(span);
    range.collapse(false);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);

    const onPaste = (ev) => {
      ev.preventDefault();
      const text = (ev.clipboardData || window.clipboardData).getData('text/plain');
      document.execCommand('insertText', false, text);
    };
    const onKey = (ev) => { if (ev.key === 'Escape') node.blur(); };
    const finish = () => {
      node.removeEventListener('paste', onPaste);
      node.removeEventListener('keydown', onKey);
      node.contentEditable = 'false';
      node.classList.remove('is-editing');
      const text = span.textContent || ' ';
      const current = S.find(el.id);
      if (current) { current.text = text; S.commit(); }
      lastTap = { id: null, t: 0 };
      F.emit('selection');
    };
    node.addEventListener('paste', onPaste);
    node.addEventListener('keydown', onKey);
    node.addEventListener('blur', finish, { once: true });
  }

  artboard.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    // Un clic en el lienzo saca el foco de cualquier campo del panel, para que los atajos vuelvan a funcionar
    const ae = document.activeElement;
    if (ae && ae.matches && ae.matches('input, select, textarea, button')) ae.blur();
    const rh = e.target.closest('.rot-handle');
    if (rh) {
      const el = S.selected()[0];
      if (el && !el.locked) gesture = { type: 'rotate', id: el.id, cx: el.x + el.w / 2, cy: el.y + el.h / 2, moved: false };
      e.preventDefault();
      return;
    }
    const handle = e.target.closest('.handle');
    if (handle) { startResize(e); e.preventDefault(); return; }

    const node = e.target.closest('.el');
    if (node && node.classList.contains('is-editing')) return;

    if (node) {
      const id = node.dataset.id;
      const el = S.find(id);
      if (!el || el.hidden) return;
      const now = Date.now();
      const dbl = el.type === 'text' && lastTap.id === id && now - lastTap.t < 350 && !e.shiftKey;
      lastTap = { id, t: now };
      if (dbl) { startEdit(node, el); return; }
      startMove(e, id);
      e.preventDefault();
      return;
    }

    // Clic en el fondo: limpia la selección o empieza un recuadro de selección
    const base = e.shiftKey ? S.selection.slice() : [];
    if (!e.shiftKey) S.setSelection([]);
    const p = pt(e);
    gesture = { type: 'marquee', start: p, base, moved: false };
    F.marquee = { x: p.x, y: p.y, w: 0, h: 0 };
    F.render.overlay();
  });

  window.addEventListener('pointermove', (e) => {
    if (!gesture) return;
    const p = pt(e);
    const z = F.zoom();
    if (gesture.type === 'move') {
      const dx0 = p.x - gesture.start.x, dy0 = p.y - gesture.start.y;
      if (!gesture.moved && Math.hypot(dx0, dy0) * z < 3) return;
      gesture.moved = true;
      const first = gesture.origins;
      const box = F.unionBox(first.map((o) => {
        const el = S.find(o.id);
        return { x: o.x + dx0, y: o.y + dy0, w: el.w, h: el.h };
      }));
      let dx = dx0, dy = dy0;
      if (F.settings.get('snap')) {
        dx = Math.round((box.x) / GRID) * GRID - (box.x - dx0);
        dy = Math.round((box.y) / GRID) * GRID - (box.y - dy0);
        F.guides = [];
      } else {
        const s = smartSnap(box, first.map((o) => o.id));
        dx += s.dx; dy += s.dy;
      }
      first.forEach((o) => {
        const el = S.find(o.id);
        if (el) { el.x = Math.round(o.x + dx); el.y = Math.round(o.y + dy); }
      });
      F.render.overlay();
      S.live();
      return;
    }
    if (gesture.type === 'rotate') {
      const el = S.find(gesture.id);
      if (!el) return;
      const q = pt(e);
      let ang = (Math.atan2(q.y - gesture.cy, q.x - gesture.cx) * 180) / Math.PI + 90;
      if (e.shiftKey) ang = Math.round(ang / 15) * 15;
      ang = ((((ang + 180) % 360) + 360) % 360) - 180;
      el.rot = Math.round(ang);
      gesture.moved = true;
      F.render.overlay();
      S.live();
      return;
    }
    if (gesture.type === 'resize') {
      const el = S.find(gesture.id);
      if (!el) return;
      const dx = p.x - gesture.start.x, dy = p.y - gesture.start.y;
      const a = (gesture.rot * Math.PI) / 180;
      // Convierte el movimiento a los ejes del elemento girado
      const lx = dx * Math.cos(a) + dy * Math.sin(a);
      const ly = -dx * Math.sin(a) + dy * Math.cos(a);
      if (!gesture.moved && Math.hypot(dx, dy) * z < 2) return;
      gesture.moved = true;
      let w = Math.max(10, gesture.ow + lx), h = Math.max(10, gesture.oh + ly);
      if (F.settings.get('snap')) {
        w = Math.max(GRID, Math.round(w / GRID) * GRID);
        h = Math.max(GRID, Math.round(h / GRID) * GRID);
      }
      el.w = Math.round(w);
      el.h = Math.round(h);
      F.render.overlay();
      S.live();
      return;
    }
    if (gesture.type === 'marquee') {
      const s = gesture.start;
      const m = { x: Math.min(s.x, p.x), y: Math.min(s.y, p.y), w: Math.abs(p.x - s.x), h: Math.abs(p.y - s.y) };
      if (!gesture.moved && m.w * z < 3 && m.h * z < 3) return;
      gesture.moved = true;
      F.marquee = m;
      const hit = S.els().filter((el) => !el.hidden &&
        el.x < m.x + m.w && el.x + el.w > m.x && el.y < m.y + m.h && el.y + el.h > m.y).map((el) => el.id);
      const ids = [...new Set([...gesture.base, ...hit])];
      S.selection = ids;
      F.emit('selection');
      F.render.overlay();
    }
  });

  function endGesture() {
    if (!gesture) return;
    const g = gesture;
    gesture = null;
    F.guides = [];
    if (g.type === 'marquee') F.marquee = null;
    if ((g.type === 'move' || g.type === 'resize' || g.type === 'rotate') && g.moved) { S.commit(); lastTap = { id: null, t: 0 }; }
    F.render.overlay();
    F.emit('selection');
  }
  window.addEventListener('pointerup', endGesture);
  window.addEventListener('pointercancel', endGesture);

  // ---------- Atajos de teclado ----------
  const shortcutsDialog = () => document.getElementById('shortcutsDialog');

  document.addEventListener('keydown', (e) => {
    // Un doble toque son dos clics seguidos: cualquier tecla lo interrumpe
    lastTap = { id: null, t: 0 };
    const mod = e.ctrlKey || e.metaKey;
    const key = e.key.toLowerCase();
    const app = document.getElementById('app');
    const isDoc = app.classList.contains('is-doc');

    if (mod && key === 's') {
      e.preventDefault();
      if (!isDoc) S.save();
      else F.emit('save-doc');
      return;
    }
    if (document.querySelector('dialog[open]')) return;
    if (inputFocused(e.target)) return;
    if (isDoc || app.classList.contains('is-home')) return;

    if (mod && key === 'z' && !e.shiftKey) { e.preventDefault(); S.undoStep(); return; }
    if (mod && (key === 'y' || (key === 'z' && e.shiftKey))) { e.preventDefault(); S.redoStep(); return; }
    if (mod && key === 'a') { e.preventDefault(); S.setSelection(S.els().filter((x) => !x.hidden).map((x) => x.id)); return; }
    if (mod && key === 'd') { e.preventDefault(); F.actions.duplicate(); return; }
    if (mod && key === 'c') { F.actions.copy(); return; }
    if (mod && key === 'v') { e.preventDefault(); F.actions.paste(); return; }
    if (mod && key === ']') { e.preventDefault(); F.actions.zorder('front'); return; }
    if (mod && key === '[') { e.preventDefault(); F.actions.zorder('back'); return; }
    if (mod) return;

    if (e.key === 'Delete' || e.key === 'Backspace') {
      if (S.selection.length) { e.preventDefault(); F.actions.remove(); }
      return;
    }
    if (e.key === 'Escape') { S.setSelection([]); return; }
    if (e.key === '?' && shortcutsDialog()) { e.preventDefault(); shortcutsDialog().showModal(); return; }
    if (e.key.startsWith('Arrow') && S.selection.length) {
      e.preventDefault();
      const step = e.shiftKey ? 10 : 1;
      const dx = e.key === 'ArrowLeft' ? -step : e.key === 'ArrowRight' ? step : 0;
      const dy = e.key === 'ArrowUp' ? -step : e.key === 'ArrowDown' ? step : 0;
      F.actions.nudge(dx, dy);
    }
  });

  F.interact = { smartSnap };
})();
