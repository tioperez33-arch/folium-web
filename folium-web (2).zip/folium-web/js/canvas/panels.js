/* Folium · paneles: propiedades del elemento, texto, lienzo, capas, orden y alineación */
(function () {
  'use strict';
  const F = window.Folium, S = F.state, $ = F.$;
  const A = () => F.actions;

  const el = {
    canvasGroup: $('#canvasGroup'), docW: $('#docW'), docH: $('#docH'), docBg: $('#docBg'),
    selGroup: $('#selGroup'), emptyHint: $('#emptyHint'), alignBar: $('#alignBar'),
    fX: $('#fX'), fY: $('#fY'), fW: $('#fW'), fH: $('#fH'), frot: $('#frot'), fOp: $('#fOp'),
    radiusRow: $('#radiusRow'), fRadius: $('#fRadius'), fillRow: $('#fillRow'), fFill: $('#fFill'),
    textGroup: $('#textGroup'), fText: $('#fText'), fSize: $('#fSize'), fFont: $('#fFont'),
    fBold: $('#fBold'), fItalic: $('#fItalic'), fAlign: $('#fAlign'),
    fLock: $('#fLock'), fHide: $('#fHide'), layers: $('#layers'),
    lineRow: $('#lineRow'), arrowRow: $('#arrowRow'), fDash: $('#fDash'), fArrow: $('#fArrow')
  };

  // Escribe un valor sin interrumpir al usuario que está escribiendo en ese campo
  function put(input, value) {
    if (document.activeElement !== input) input.value = value;
  }

  // Enlace entre un campo numérico y una propiedad de todos los seleccionados
  function bindNumber(input, read, write, min, max) {
    input.addEventListener('input', () => {
      const v = Number(input.value);
      if (!Number.isFinite(v)) return;
      write(F.clamp(v, min, max));
      S.live();
    });
    input.addEventListener('change', () => S.commit());
  }

  function bindText(input, write) {
    input.addEventListener('input', () => { write(input.value); S.live(); });
    input.addEventListener('change', () => S.commit());
  }

  // ----- Lienzo -----
  bindNumber(el.docW, null, (v) => { S.canvas().width = Math.round(v); }, 200, 4000);
  bindNumber(el.docH, null, (v) => { S.canvas().height = Math.round(v); }, 200, 4000);
  el.docBg.addEventListener('input', () => { S.canvas().background = el.docBg.value; S.live(); });
  el.docBg.addEventListener('change', () => S.commit());
  $('#bgTransparent').addEventListener('change', (e) => {
    S.canvas().background = e.target.checked ? 'transparent' : '#FFFFFF';
    S.commit();
  });

  // ----- Posición y tamaño (un solo elemento) -----
  const single = () => (S.selected().length === 1 ? S.selected()[0] : null);
  bindNumber(el.fX, null, (v) => { const s = single(); if (s) s.x = Math.round(v); }, -10000, 10000);
  bindNumber(el.fY, null, (v) => { const s = single(); if (s) s.y = Math.round(v); }, -10000, 10000);
  bindNumber(el.fW, null, (v) => { const s = single(); if (s) s.w = Math.round(v); }, 10, 10000);
  bindNumber(el.fH, null, (v) => { const s = single(); if (s) s.h = Math.round(v); }, 10, 10000);
  bindNumber(el.frot, null, (v) => { const s = single(); if (s) s.rot = Math.round(v); }, -360, 360);
  bindNumber(el.fOp, null, (v) => { S.selected().forEach((s) => { s.op = v / 100; }); }, 0, 100);
  bindNumber(el.fRadius, null, (v) => { S.selected().forEach((s) => { if (s.type === 'rect') s.radius = Math.round(v); }); }, 0, 500);

  bindText(el.fFill, (v) => { S.selected().forEach((s) => { if (s.type !== 'image') s.fill = v; }); });
  bindText(el.fText, (v) => { const s = single(); if (s && s.type === 'text') s.text = v; });
  bindNumber(el.fSize, null, (v) => { S.selected().forEach((s) => { if (s.type === 'text') s.size = Math.round(v); }); }, 8, 400);

  el.fFont.addEventListener('change', () => {
    S.selected().forEach((s) => { if (s.type === 'text') s.font = el.fFont.value; });
    S.commit();
  });
  el.fBold.addEventListener('click', () => {
    const texts = S.selected().filter((s) => s.type === 'text');
    const on = texts.length && texts[0].weight >= 600;
    texts.forEach((s) => { s.weight = on ? 400 : 700; });
    S.commit();
  });
  el.fItalic.addEventListener('click', () => {
    const texts = S.selected().filter((s) => s.type === 'text');
    const on = texts.length && texts[0].italic;
    texts.forEach((s) => { s.italic = !on; });
    S.commit();
  });
  el.fAlign.addEventListener('click', (ev) => {
    const b = ev.target.closest('button[data-al]');
    if (!b) return;
    S.selected().forEach((s) => { if (s.type === 'text') s.align = b.dataset.al; });
    S.commit();
  });

  el.fLock.addEventListener('change', () => {
    S.selected().forEach((s) => { s.locked = el.fLock.checked; });
    S.commit();
  });
  el.fHide.addEventListener('change', () => {
    S.selected().forEach((s) => { s.hidden = el.fHide.checked; });
    S.commit();
  });

  // ----- Estilo de línea -----
  el.fDash.addEventListener('change', () => {
    S.selected().forEach((s) => { if (s.type === 'line') s.dash = el.fDash.value; });
    S.commit();
  });
  el.fArrow.addEventListener('change', () => {
    S.selected().forEach((s) => { if (s.type === 'line') s.arrow = el.fArrow.value; });
    S.commit();
  });

  // ----- Acciones -----
  $('#dupBtn').addEventListener('click', () => A().duplicate());
  $('#delBtn').addEventListener('click', () => A().remove());
  $$('[data-z]').forEach((b) => b.addEventListener('click', () => A().zorder(b.dataset.z)));
  $$('[data-align]').forEach((b) => b.addEventListener('click', () => A().align(b.dataset.align)));
  function $$(sel) { return F.$$(sel); }

  // ----- Capas -----
  function renderLayers() {
    const list = el.layers;
    if (!list) return;
    const selected = new Set(S.selection);
    const items = S.els().slice().reverse();
    list.innerHTML = '';
    if (!items.length) {
      const li = document.createElement('li');
      li.className = 'empty';
      li.textContent = 'Aún no hay elementos.';
      list.appendChild(li);
      return;
    }
    items.forEach((it) => {
      const li = document.createElement('li');
      li.dataset.id = it.id;
      li.className = selected.has(it.id) ? 'sel' : '';
      const label = it.type === 'text' ? (it.text || '').slice(0, 26) : (it.name || it.type);
      li.innerHTML = `<span class="nm">${F.esc(label)}<small>${F.esc(it.type)}</small></span>
        <span class="tg">
          <button type="button" data-tg="hidden" aria-pressed="${it.hidden ? 'true' : 'false'}" aria-label="${it.hidden ? 'Mostrar' : 'Ocultar'}" title="${it.hidden ? 'Mostrar' : 'Ocultar'}">${it.hidden ? '○' : '●'}</button>
          <button type="button" data-tg="locked" aria-pressed="${it.locked ? 'true' : 'false'}" aria-label="${it.locked ? 'Desbloquear' : 'Bloquear'}" title="${it.locked ? 'Desbloquear' : 'Bloquear'}">${it.locked ? '🔒' : '🔓'}</button>
        </span>`;
      list.appendChild(li);
    });
  }

  el.layers && el.layers.addEventListener('click', (ev) => {
    const li = ev.target.closest('li[data-id]');
    if (!li) return;
    const id = li.dataset.id;
    const tg = ev.target.closest('button[data-tg]');
    // Segundo clic seguido (detail 2): renombrar la capa. Se usa el número de clics porque la lista se reconstruye al seleccionar
    if (ev.detail === 2 && !tg) {
      const item = S.find(id);
      const name = item && window.prompt('Nombre de la capa:', item.name || item.type);
      if (name && name.trim()) { item.name = name.trim(); S.commit(); }
      return;
    }
    if (tg) {
      const item = S.find(id);
      if (!item) return;
      item[tg.dataset.tg] = !item[tg.dataset.tg];
      S.commit();
      return;
    }
    if (ev.shiftKey) {
      const ids = S.selection.includes(id) ? S.selection.filter((x) => x !== id) : [...S.selection, id];
      S.setSelection(ids);
    } else {
      S.setSelection([id]);
    }
  });

  // ----- Actualización de la vista -----
  function updatePanels() {
    put(el.docW, S.canvas().width);
    put(el.docH, S.canvas().height);
    el.docBg.value = /^#[0-9a-f]{6}$/i.test(S.canvas().background) ? S.canvas().background : '#ffffff';
    $('#bgTransparent').checked = S.canvas().background === 'transparent';

    const sel = S.selected();
    const hasSel = sel.length > 0;
    el.selGroup.hidden = !hasSel;
    el.emptyHint.hidden = hasSel;
    el.alignBar.hidden = sel.length < 2;
    el.textGroup.hidden = !hasSel || !sel.some((x) => x.type === 'text');
    $('#elActions').hidden = !hasSel;
    if (sel.length >= 2) {
      const dv = sel.length >= 3;
      $$('[data-align="dh"], [data-align="dv"]').forEach((b) => { b.disabled = !dv; });
    }
    if (!hasSel) { renderLayers(); return; }

    const s = sel[0];
    const one = sel.length === 1;
    [el.fX, el.fY, el.fW, el.fH, el.frot].forEach((i) => { i.disabled = !one; });
    if (one) {
      put(el.fX, Math.round(s.x)); put(el.fY, Math.round(s.y));
      put(el.fW, Math.round(s.w)); put(el.fH, Math.round(s.h));
      put(el.frot, Math.round(s.rot || 0));
    } else {
      put(el.fX, ''); put(el.fY, ''); put(el.fW, ''); put(el.fH, ''); put(el.frot, '');
    }
    put(el.fOp, Math.round((s.op == null ? 1 : s.op) * 100));
    el.radiusRow.hidden = !sel.some((x) => x.type === 'rect');
    if (s.type === 'rect' || sel.some((x) => x.type === 'rect')) put(el.fRadius, s.radius || 0);
    el.fillRow.hidden = sel.every((x) => x.type === 'image');
    const lines = sel.filter((x) => x.type === 'line');
    el.lineRow.hidden = !lines.length;
    el.arrowRow.hidden = !lines.length;
    if (lines.length) {
      el.fDash.value = lines[0].dash || 'solid';
      el.fArrow.value = lines[0].arrow || 'none';
    }
    const fillSrc = sel.find((x) => x.type !== 'image');
    if (fillSrc && /^#[0-9a-f]{6}$/i.test(fillSrc.fill)) el.fFill.value = fillSrc.fill;

    const texts = sel.filter((x) => x.type === 'text');
    if (texts.length) {
      const t = texts[0];
      put(el.fSize, t.size);
      el.fFont.value = t.font || 'inter';
      el.fBold.setAttribute('aria-pressed', String(t.weight >= 600));
      el.fItalic.setAttribute('aria-pressed', String(!!t.italic));
      $$('#fAlign button[data-al]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.al === (t.align || 'left'))));
      if (one && t.type === 'text' && document.activeElement !== el.fText) el.fText.value = t.text;
      el.fText.disabled = !one;
    }
    el.fLock.checked = sel.every((x) => x.locked);
    el.fHide.checked = sel.every((x) => x.hidden);
    renderLayers();
  }

  F.on('selection', updatePanels);
  F.on('change', updatePanels);
  F.on('history', updatePanels);
  F.on('project', updatePanels);
  F.on('live', updatePanels);

  F.panels = { update: updatePanels };
})();
