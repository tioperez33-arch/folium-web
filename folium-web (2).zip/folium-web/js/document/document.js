/* Folium · modo documento: hoja editable con cinta de formato, imágenes editables (forma, proporción, tamaño,
   filtros, volteo), texto con degradado, tipografías, y guardado dentro del proyecto */
(function () {
  'use strict';
  const F = window.Folium, S = F.state, $ = F.$;
  const page = $('#page');
  let timer = null;
  let edited = false; // true solo cuando el usuario escribió o dio formato desde la última carga
  let saved = null;   // última selección dentro de la hoja (los controles de la cinta la quitan)
  let selImg = null;  // imagen seleccionada para editar

  const DOC_FONTS = ['Inter', 'Montserrat', 'Poppins', 'Oswald', 'Bebas Neue', 'Playfair Display', 'Lora', 'Merriweather', 'Georgia', 'Pacifico', 'Dancing Script', 'Courier New'];

  // ----- Guardado -----
  function flush() {
    const p = S.project();
    if (!p || !edited) return;
    edited = false;
    if (p.doc.html === page.innerHTML) return;
    p.doc.html = page.innerHTML;
    S.persist();
  }

  function load() {
    const p = S.project();
    if (!p) return;
    edited = false;
    selImg = null;
    if (page.innerHTML !== p.doc.html) page.innerHTML = p.doc.html;
    hideImgBar();
  }

  function changed() {
    edited = true;
    flush();
  }

  page.addEventListener('input', () => {
    edited = true;
    clearTimeout(timer);
    timer = setTimeout(flush, 400);
  });
  page.addEventListener('blur', flush);

  // ----- Selección y comandos -----
  document.addEventListener('selectionchange', () => {
    const sel = window.getSelection();
    if (sel && sel.rangeCount && page.contains(sel.anchorNode)) saved = sel.getRangeAt(0).cloneRange();
  });

  function restore() {
    page.focus({ preventScroll: true });
    if (!saved) return;
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(saved);
  }

  function exec(cmd, value, css) {
    restore();
    if (css) document.execCommand('styleWithCSS', false, true);
    document.execCommand(cmd, false, value == null ? null : value);
    if (css) document.execCommand('styleWithCSS', false, false);
    changed();
  }

  // Aplica un estilo (tamaño, degradado) al texto seleccionado
  function wrap(style) {
    restore();
    const sel = window.getSelection();
    if (!sel.rangeCount || sel.isCollapsed) { F.toast('Selecciona primero el texto', '', 1800); return; }
    const range = sel.getRangeAt(0);
    const span = document.createElement('span');
    Object.assign(span.style, style);
    span.appendChild(range.extractContents());
    range.insertNode(span);
    const r = document.createRange();
    r.selectNodeContents(span);
    sel.removeAllRanges();
    sel.addRange(r);
    saved = r.cloneRange();
    changed();
  }

  function insertHtml(html) {
    restore();
    document.execCommand('insertHTML', false, html);
    changed();
  }

  // ----- Imágenes editables -----
  const SHAPE_CLIP = (s) => {
    if (s === 'circle') return 'circle(50% at 50% 50%)';
    if (s === 'rounded') return 'inset(0 round 18px)';
    if (s === 'rect' || !s) return 'none';
    return 'polygon(' + F.shapePoints(s).map((p) => p[0].toFixed(1) + '% ' + p[1].toFixed(1) + '%').join(', ') + ')';
  };
  const ALIGN_MARGIN = { left: '12px auto 12px 0', center: '12px auto', right: '12px 0 12px auto' };

  // Escribe el estilo de la imagen a partir de sus atributos data-*
  function renderImg(img) {
    const d = img.dataset;
    const filters = [];
    if (d.br && d.br !== '100') filters.push(`brightness(${d.br}%)`);
    if (d.gs && d.gs !== '0') filters.push(`grayscale(${d.gs}%)`);
    if (d.se && d.se !== '0') filters.push(`sepia(${d.se}%)`);
    const transform = [
      d.rot && d.rot !== '0' ? `rotate(${d.rot}deg)` : '',
      d.fh === '1' ? 'scaleX(-1)' : '',
      d.fv === '1' ? 'scaleY(-1)' : ''
    ].filter(Boolean).join(' ');
    const ratio = d.ratio && d.ratio !== 'auto' ? `aspect-ratio:${d.ratio};object-fit:cover;` : '';
    img.style.cssText = [
      'display:block', 'max-width:100%', `width:${d.size || 100}%`, 'height:auto', ratio,
      `margin:${ALIGN_MARGIN[d.align || 'center']}`,
      `clip-path:${SHAPE_CLIP(d.shape)}`,
      `filter:${filters.join(' ') || 'none'}`,
      `transform:${transform || 'none'}`
    ].join(';') + ';';
    img.classList.add('img-sel');
  }

  function showImgBar(img) {
    selImg = img;
    const bar = $('#imgBar');
    const d = img.dataset;
    $('#imShape').value = d.shape || 'rect';
    $('#imRatio').value = d.ratio || 'auto';
    $('#imSize').value = d.size || '100';
    $('#imAl').value = d.align || 'center';
    $('#imBr').value = d.br || '100';
    $('#imGs').value = d.gs || '0';
    $('#imSe').value = d.se || '0';
    bar.hidden = false;
  }

  function hideImgBar() {
    selImg = null;
    const bar = $('#imgBar');
    if (bar) bar.hidden = true;
    page.querySelectorAll('img.img-sel').forEach((i) => i.classList.remove('img-sel'));
  }

  // Cambia un atributo de la imagen seleccionada y la vuelve a dibujar
  function setImg(key, value) {
    if (!selImg) return;
    selImg.dataset[key] = value;
    renderImg(selImg);
    changed();
  }

  page.addEventListener('click', (e) => {
    const img = e.target.closest('img');
    if (img && page.contains(img)) {
      e.preventDefault();
      if (selImg !== img) {
        hideImgBar();
        showImgBar(img);
        img.classList.add('img-sel');
      }
      return;
    }
    if (selImg) hideImgBar();
  });

  page.addEventListener('keydown', (e) => {
    if (!selImg) return;
    if (e.key === 'Delete' || e.key === 'Backspace') {
      e.preventDefault();
      const img = selImg;
      hideImgBar();
      img.remove();
      changed();
    }
  });

  $('#imShape').addEventListener('change', (e) => setImg('shape', e.target.value));
  $('#imRatio').addEventListener('change', (e) => setImg('ratio', e.target.value));
  $('#imSize').addEventListener('change', (e) => setImg('size', e.target.value));
  $('#imAl').addEventListener('change', (e) => setImg('align', e.target.value));
  $('#imBr').addEventListener('input', (e) => { if (selImg) { selImg.dataset.br = e.target.value; renderImg(selImg); } });
  $('#imBr').addEventListener('change', (e) => setImg('br', e.target.value));
  $('#imGs').addEventListener('input', (e) => { if (selImg) { selImg.dataset.gs = e.target.value; renderImg(selImg); } });
  $('#imGs').addEventListener('change', (e) => setImg('gs', e.target.value));
  $('#imSe').addEventListener('input', (e) => { if (selImg) { selImg.dataset.se = e.target.value; renderImg(selImg); } });
  $('#imSe').addEventListener('change', (e) => setImg('se', e.target.value));
  $('#imFlipH').addEventListener('click', () => { if (selImg) setImg('fh', selImg.dataset.fh === '1' ? '0' : '1'); });
  $('#imFlipV').addEventListener('click', () => { if (selImg) setImg('fv', selImg.dataset.fv === '1' ? '0' : '1'); });
  $('#imRot').addEventListener('click', () => { if (selImg) setImg('rot', String(((Number(selImg.dataset.rot) || 0) + 90) % 360)); });
  $('#imDel').addEventListener('click', () => {
    if (!selImg) return;
    const img = selImg;
    hideImgBar();
    img.remove();
    changed();
  });

  // ----- Cinta de formato -----
  $$('[data-cmd]').forEach((btn) => {
    btn.addEventListener('click', () => exec(btn.dataset.cmd, btn.dataset.value, btn.dataset.css === '1'));
  });
  $('#dStyle').addEventListener('change', (e) => exec('formatBlock', e.target.value));
  $('#dFont').addEventListener('change', (e) => exec('fontName', e.target.value));
  $('#dSize').addEventListener('change', (e) => wrap({ fontSize: e.target.value + 'px' }));
  $('#dColor').addEventListener('change', (e) => exec('foreColor', e.target.value));
  $('#dHi').addEventListener('change', (e) => exec('hiliteColor', e.target.value, true));
  $('#dGrad').addEventListener('change', (e) => {
    const g = F.GRADIENTS[e.target.value];
    e.target.value = '';
    if (!g) return;
    wrap({
      background: `linear-gradient(90deg, ${g.c1}, ${g.c2})`,
      webkitBackgroundClip: 'text', backgroundClip: 'text',
      webkitTextFillColor: 'transparent', color: 'transparent'
    });
  });

  $$('[data-act]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const act = btn.dataset.act;
      if (act === 'link') {
        const url = window.prompt('Dirección del enlace (empieza con https://)', 'https://');
        if (url && url.trim()) exec('createLink', url.trim());
      }
      if (act === 'image') $('#docImage').click();
      if (act === 'table') {
        const cell = '<td style="border:1px solid #C9D1E6;padding:6px 8px">&nbsp;</td>';
        const row = `<tr>${cell}${cell}${cell}</tr>`;
        insertHtml(`<table style="border-collapse:collapse;width:100%;margin:12px 0">${row}${row}${row}</table><p></p>`);
      }
    });
  });

  $('#docImage').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    e.target.value = '';
    if (!file) return;
    try {
      const img = await F.io.importImage(file);
      const tag = 'img-' + Math.random().toString(36).slice(2, 8);
      insertHtml(`<img id="${tag}" src="${img.src}" alt="" data-size="50" data-align="center" data-shape="rect" data-ratio="auto" data-br="100" data-gs="0" data-se="0" data-rot="0" data-fh="0" data-fv="0">`);
      const inserted = document.getElementById(tag);
      if (inserted) {
        inserted.removeAttribute('id');
        renderImg(inserted);
        changed();
      }
    } catch (err) {
      F.toast(err.message || 'No se pudo insertar la imagen', 'error');
    }
  });

  function $$(sel) { return F.$$(sel); }

  // ----- Opciones de las listas -----
  function fillOptions() {
    const font = $('#dFont');
    if (font && !font.options.length) DOC_FONTS.forEach((f) => { const o = document.createElement('option'); o.value = f; o.textContent = f; font.appendChild(o); });
    const grad = $('#dGrad');
    if (grad && !grad.options.length) {
      const first = document.createElement('option');
      first.value = ''; first.textContent = 'Degradado de texto';
      grad.appendChild(first);
      Object.keys(F.GRADIENTS).forEach((k) => { const o = document.createElement('option'); o.value = k; o.textContent = F.GRADIENTS[k].label; grad.appendChild(o); });
    }
    const shape = $('#imShape');
    if (shape && !shape.options.length) {
      [['rect', 'Rectángulo'], ['rounded', 'Esquinas redondeadas'], ['circle', 'Círculo']].forEach(([v, l]) => {
        const o = document.createElement('option'); o.value = v; o.textContent = l; shape.appendChild(o);
      });
      Object.keys(F.SHAPES).forEach((k) => { const o = document.createElement('option'); o.value = k; o.textContent = F.SHAPES[k]; shape.appendChild(o); });
    }
  }

  F.on('project', load);
  F.on('save-doc', () => { flush(); S.save(); F.toast('Guardado', 'ok', 1200); });

  F.document = {
    init() { fillOptions(); load(); },
    load,
    flush,
    setHtml(html) {
      page.innerHTML = html;
      edited = true;
      flush();
    },
    html: () => { flush(); return S.project().doc.html; }
  };
})();
